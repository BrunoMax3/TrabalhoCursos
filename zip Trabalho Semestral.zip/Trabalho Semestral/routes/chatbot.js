const express = require('express');
const router = express.Router();

// Mock de cursos para recomendação
const cursos = [
  { id: 1, title: "Introdução ao JavaScript", level: "Iniciante", keywords: ["javascript", "js", "iniciante", "básico"] },
  { id: 2, title: "TypeScript para Backend", level: "Intermediário", keywords: ["typescript", "backend", "intermediário"] },
  { id: 3, title: "React para Iniciantes", level: "Iniciante", keywords: ["react", "frontend", "iniciante"] },
  { id: 4, title: "Node.js Avançado", level: "Avançado", keywords: ["node", "nodejs", "avançado"] }
];

// Função para calcular score de relevância
function calculateRelevance(message, course) {
  const messageLower = message.toLowerCase();
  let score = 0;
  
  course.keywords.forEach(keyword => {
    if (messageLower.includes(keyword)) {
      score += 0.3;
    }
  });
  
  return Math.min(score, 1.0);
}

router.post('/', (req, res) => {
  const { message, userId } = req.body;

  // Validação
  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'Mensagem inválida' });
  }

  if (!userId || typeof userId !== 'string') {
    return res.status(400).json({ error: 'userId inválido' });
  }

  // Processar recomendações
  const recommendations = cursos
    .map(course => ({
      id: course.id,
      title: course.title,
      level: course.level,
      score: calculateRelevance(message, course)
    }))
    .filter(rec => rec.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  // Resposta
  res.json({
    reply: `Recebi sua mensagem: "${message}"`,
    recommendations
  });
});

module.exports = router;
