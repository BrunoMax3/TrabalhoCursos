INSERT INTO users (name, email, password_hash, role)
VALUES ('Administrador', 'admin@cursosplat.com', '<hash_da_senha>', 'admin');
