const API_URL = 'http://localhost:5000/api';

document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', handleSignup);
    }
});

async function handleSignup(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword')?.value;
    const errorMessage = document.getElementById('errorMessage');
    const submitButton = event.target.querySelector('button[type="submit"]');
    
    // Validações
    if (confirmPassword && password !== confirmPassword) {
        showError(errorMessage, 'As senhas não coincidem!');
        return;
    }
    
    if (password.length < 6) {
        showError(errorMessage, 'A senha deve ter pelo menos 6 caracteres!');
        return;
    }
    
    if (errorMessage) errorMessage.style.display = 'none';
    submitButton.disabled = true;
    submitButton.textContent = 'Criando conta...';
    
    // Tentar backend primeiro
    const backendAvailable = await checkBackend();
    
    if (backendAvailable) {
        try {
            const response = await fetch(`${API_URL}/auth/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password }),
                signal: AbortSignal.timeout(5000)
            });
            
            if (response.ok) {
                alert('Conta criada com sucesso! Faça login para continuar.');
                window.location.href = 'login.html';
                return;
            }
        } catch (error) {
            console.log('Backend indisponível, criando conta local');
        }
    }
    
    // Criar conta local
    const user = {
        name: name,
        email: email,
        interests: ['Programação', 'Frontend', 'Backend']
    };
    
    localStorage.setItem('user', JSON.stringify(user));
    alert('Conta criada com sucesso!');
    window.location.href = 'profile.html';
}

async function checkBackend() {
    try {
        const response = await fetch(`${API_URL}/health`, {
            signal: AbortSignal.timeout(2000)
        });
        return response.ok;
    } catch {
        return false;
    }
}

function showError(errorElement, message) {
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
}
