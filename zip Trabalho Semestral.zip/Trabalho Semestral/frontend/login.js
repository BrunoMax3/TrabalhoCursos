const API_URL = 'http://localhost:5000/api';

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
});

async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('errorMessage');
    const submitButton = event.target.querySelector('button[type="submit"]');
    
    // Limpar mensagem de erro
    if (errorMessage) {
        errorMessage.style.display = 'none';
    }
    
    // Desabilitar botão durante requisição
    submitButton.disabled = true;
    submitButton.textContent = 'Entrando...';
    
    // Tentar backend primeiro
    const backendAvailable = await checkBackend();
    
    if (backendAvailable) {
        try {
            const response = await fetch(`${API_URL}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password }),
                signal: AbortSignal.timeout(5000)
            });
            
            const data = await response.json();
            
            if (response.ok && data.token) {
                // Salvar token e dados do usuário
                localStorage.setItem('token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));
                
                alert('Login realizado com sucesso!');
                window.location.href = 'index.html';
                return;
            } else {
                throw new Error(data.message || 'Erro ao fazer login');
            }
        } catch (error) {
            alert(`❌ ${error.message}`);
            submitButton.disabled = false;
            submitButton.textContent = 'Entrar';
        }
    }
}

async function checkBackend() {
    try {
        const response = await fetch(`${API_URL}/health`, {
            signal: AbortSignal.timeout(2000)
        });
        return response.ok;
    } catch {
        return false;
    }
}

function showError(errorElement, message) {
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
}

function loginDemo() {
    const demoUser = {
        id: 1,
        name: 'Bruno Demo',
        email: 'demo@cursosplat.com',
        role: 'student'
    };
    
    localStorage.setItem('token', 'demo_token_12345');
    localStorage.setItem('user', JSON.stringify(demoUser));
    alert('✅ Login demo realizado!');
    window.location.href = 'index.html';
}
