const API_URL = 'http://localhost:5000/api';
const userId = 'user-' + Date.now();

let allCourses = [];

// Carregar cursos ao iniciar
document.addEventListener('DOMContentLoaded', () => {
    loadAllCourses();
    loadFeaturedCourses();
    setupChatInput();
    checkAuth();
});

// Configurar input do chat
function setupChatInput() {
    const chatInput = document.getElementById('chatInput');
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
}

// Scroll suave para o chatbot
function scrollToChatbot() {
    document.getElementById('chatbot').scrollIntoView({ behavior: 'smooth' });
}

// Enviar mensagem ao chatbot
async function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Adicionar mensagem do usuário
    addMessageToChat('user', message);
    input.value = '';
    
    // Mostrar loading
    const loadingId = addMessageToChat('bot', 'Pensando... 🤔');
    
    try {
        const response = await fetch(`${API_URL}/chatbot`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message, userId })
        });
        
        if (!response.ok) throw new Error('Erro na resposta');
        
        const data = await response.json();
        
        // Remover loading
        removeMessage(loadingId);
        
        // Adicionar resposta do bot
        addMessageToChat('bot', data.reply);
        
        // Mostrar recomendações
        if (data.recommendations && data.recommendations.length > 0) {
            displayRecommendations(data.recommendations);
        }
        
    } catch (error) {
        removeMessage(loadingId);
        addMessageToChat('bot', 'Desculpe, ocorreu um erro. Tente novamente.');
        console.error('Erro:', error);
    }
}

// Adicionar mensagem ao chat
function addMessageToChat(type, content) {
    const messagesDiv = document.getElementById('chatMessages');
    const messageId = 'msg-' + Date.now();
    
    const messageDiv = document.createElement('div');
    messageDiv.id = messageId;
    messageDiv.className = `message ${type}-message`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.innerHTML = content;
    
    messageDiv.appendChild(contentDiv);
    messagesDiv.appendChild(messageDiv);
    
    // Scroll para baixo
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
    
    return messageId;
}

// Remover mensagem
function removeMessage(messageId) {
    const message = document.getElementById(messageId);
    if (message) message.remove();
}

// Exibir recomendações
function displayRecommendations(recommendations) {
    const container = document.getElementById('recommendations');
    const list = document.getElementById('recommendationsList');
    
    list.innerHTML = '';
    
    recommendations.forEach(rec => {
        const card = document.createElement('div');
        card.className = 'recommendation-card';
        card.onclick = () => openCourseDetails(rec.id);
        card.innerHTML = `
            <div class="recommendation-header">
                <h4>${rec.title}</h4>
                <span class="score-badge">${(rec.score * 100).toFixed(0)}% Match</span>
            </div>
            <div>
                <span class="level-badge">${rec.level}</span>
                <span class="level-badge">${rec.category}</span>
            </div>
            <p class="reason-text">💡 ${rec.reason}</p>
            ${rec.price ? `<p class="course-price">R$ ${rec.price.toFixed(2)}</p>` : ''}
            ${rec.rating ? `<p style="color: #666; margin-top: 0.5rem;">⭐ ${rec.rating} • 👥 ${rec.students || 0} alunos</p>` : ''}
        `;
        list.appendChild(card);
    });
    
    container.style.display = 'block';
    
    // Scroll suave para as recomendações
    setTimeout(() => {
        container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 300);
}

// Carregar todos os cursos
async function loadAllCourses() {
    const coursesGrid = document.getElementById('coursesList');
    coursesGrid.innerHTML = '<div class="loading">Carregando cursos...</div>';
    
    try {
        const response = await fetch(`${API_URL}/courses`);
        if (!response.ok) throw new Error('Erro ao carregar cursos');
        
        allCourses = await response.json();
        displayCourses(allCourses);
        
    } catch (error) {
        coursesGrid.innerHTML = '<div class="loading">❌ Erro ao carregar cursos. Verifique se o servidor está rodando.</div>';
        console.error('Erro:', error);
    }
}

function displayCourses(courses) {
    const coursesGrid = document.getElementById('coursesList');
    coursesGrid.innerHTML = '';
    
    if (courses.length === 0) {
        coursesGrid.innerHTML = '<div class="loading">Nenhum curso encontrado.</div>';
        return;
    }
    
    courses.forEach(course => {
        const card = createCourseCard(course);
        coursesGrid.appendChild(card);
    });
}

function createCourseCard(course) {
    const card = document.createElement('div');
    card.className = 'course-card';
    card.onclick = () => openCourseDetails(course.id);
    card.innerHTML = `
        <div class="course-card-header">
            <h3>${course.title}</h3>
            <div class="course-badges">
                <span class="level-badge">${course.level}</span>
                <span class="category-badge">${course.category}</span>
            </div>
        </div>
        <div class="course-card-body">
            <p>${course.description}</p>
            <div class="course-stats">
                <span>⭐ ${course.rating || 4.5}</span>
                <span>👥 ${course.students || 0} alunos</span>
                <span>⏱️ ${course.duration}</span>
            </div>
            <div class="course-footer">
                <div class="course-price">R$ ${course.price.toFixed(2)}</div>
                <button class="btn-details" onclick="event.stopPropagation(); openCourseDetails(${course.id})">Ver Detalhes</button>
            </div>
        </div>
    `;
    return card;
}

async function loadFeaturedCourses() {
    const featuredGrid = document.getElementById('featuredCourses');
    featuredGrid.innerHTML = '<div class="loading">Carregando cursos em destaque...</div>';
    
    try {
        const response = await fetch(`${API_URL}/courses`);
        if (!response.ok) throw new Error('Erro ao carregar cursos');
        
        const allCourses = await response.json();
        
        // Pegar os 6 cursos com melhor avaliação
        const featured = allCourses
            .sort((a, b) => (b.rating || 0) - (a.rating || 0))
            .slice(0, 6);
        
        featuredGrid.innerHTML = '';
        
        featured.forEach(course => {
            const card = createFeaturedCard(course);
            featuredGrid.appendChild(card);
        });
        
    } catch (error) {
        featuredGrid.innerHTML = '<div class="loading">Erro ao carregar cursos.</div>';
        console.error('Erro:', error);
    }
}

function createFeaturedCard(course) {
    const card = document.createElement('div');
    card.className = 'course-card';
    card.style.position = 'relative';
    card.onclick = () => openCourseDetails(course.id);
    card.innerHTML = `
        <span class="featured-badge">🌟 Destaque</span>
        <div class="course-card-header">
            <h3>${course.title}</h3>
            <div class="course-badges">
                <span class="level-badge">${course.level}</span>
                <span class="category-badge">${course.category}</span>
            </div>
        </div>
        <div class="course-card-body">
            <p>${course.description}</p>
            <div class="course-stats">
                <span>⭐ ${course.rating || 4.5}</span>
                <span>👥 ${course.students || 0} alunos</span>
                <span>⏱️ ${course.duration}</span>
            </div>
            <div class="course-footer">
                <div class="course-price">R$ ${course.price.toFixed(2)}</div>
                <button class="btn-details" onclick="event.stopPropagation(); openCourseDetails(${course.id})">Ver Detalhes</button>
            </div>
        </div>
    `;
    return card;
}

// Filter by category
function filterByCategory(category) {
    document.getElementById('categoryFilter').value = category;
    filterCourses();
    document.getElementById('courses').scrollIntoView({ behavior: 'smooth' });
}

// FAQ Toggle
function toggleFAQ(index) {
    const faqItems = document.querySelectorAll('.faq-item');
    const item = faqItems[index];
    
    // Fechar outros
    faqItems.forEach((faq, i) => {
        if (i !== index) {
            faq.classList.remove('active');
        }
    });
    
    // Toggle atual
    item.classList.toggle('active');
}

// Rating System
function openRatingModal(courseId) {
    currentRatingCourse = courseId;
    selectedRating = 0;
    document.getElementById('ratingModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    updateStars();
}

function closeRatingModal() {
    document.getElementById('ratingModal').style.display = 'none';
    document.body.style.overflow = 'auto';
    document.getElementById('ratingComment').value = '';
    selectedRating = 0;
    updateStars();
}

function setRating(rating) {
    selectedRating = rating;
    updateStars();
}

function updateStars() {
    const stars = document.querySelectorAll('.rating-stars .star');
    stars.forEach((star, index) => {
        if (index < selectedRating) {
            star.classList.add('active');
            star.textContent = '★';
        } else {
            star.classList.remove('active');
            star.textContent = '☆';
        }
    });
}

function submitRating() {
    if (selectedRating === 0) {
        alert('Por favor, selecione uma classificação!');
        return;
    }
    
    const comment = document.getElementById('ratingComment').value;
    
    console.log('Rating submitted:', {
        courseId: currentRatingCourse,
        rating: selectedRating,
        comment: comment
    });
    
    alert(`Obrigado pela sua avaliação de ${selectedRating} estrelas!`);
    closeRatingModal();
}

// Adicionar botão de avaliar no modal de detalhes
async function openCourseDetails(courseId) {
    const modal = document.getElementById('courseModal');
    const detailsDiv = document.getElementById('courseDetails');
    
    detailsDiv.innerHTML = '<div class="loading">Carregando...</div>';
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    try {
        const response = await fetch(`${API_URL}/courses/${courseId}`);
        if (!response.ok) throw new Error('Erro ao carregar detalhes');
        
        const course = await response.json();
        
        detailsDiv.innerHTML = `
            <div class="course-detail-header">
                <h2>${course.title}</h2>
                <div class="course-badges">
                    <span class="level-badge">${course.level}</span>
                    <span class="category-badge">${course.category}</span>
                </div>
            </div>
            
            <div class="course-detail-body">
                <div class="course-stats-large">
                    <div class="stat">
                        <span class="stat-value">⭐ ${course.rating || 4.5}</span>
                        <span class="stat-label">Avaliação</span>
                    </div>
                    <div class="stat">
                        <span class="stat-value">👥 ${(course.students || 0).toLocaleString()}</span>
                        <span class="stat-label">Alunos</span>
                    </div>
                    <div class="stat">
                        <span class="stat-value">📚 ${course.modules || 10}</span>
                        <span class="stat-label">Módulos</span>
                    </div>
                    <div class="stat">
                        <span class="stat-value">⏱️ ${course.duration}</span>
                        <span class="stat-label">Duração</span>
                    </div>
                </div>
                
                <div class="course-description">
                    <h3>📝 Sobre o Curso</h3>
                    <p>${course.detailedDescription || course.description}</p>
                </div>
                
                <div class="course-instructor">
                    <h3>👨‍🏫 Instrutor</h3>
                    <p>${course.instructor}</p>
                </div>
                
                <div style="text-align: center; margin: 2rem 0;">
                    <button class="btn-details" onclick="event.stopPropagation(); closeModal(); openRatingModal(${course.id})">
                        ⭐ Avaliar Curso
                    </button>
                </div>
                
                <div class="course-price-section">
                    <div class="price-large">R$ ${course.price.toFixed(2)}</div>
                    <button class="btn-buy" onclick="buyCourse(${course.id}, '${course.title}')">
                        🛒 Comprar Agora
                    </button>
                </div>
            </div>
        `;
        
    } catch (error) {
        detailsDiv.innerHTML = '<div class="loading">❌ Erro ao carregar detalhes.</div>';
        console.error('Erro:', error);
    }
}

function closeModal() {
    const modal = document.getElementById('courseModal');
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

function buyCourse(courseId, courseTitle) {
    alert(`🎉 Curso "${courseTitle}" adicionado ao carrinho!\n\nEm breve você será redirecionado para o pagamento.`);
    closeModal();
}

window.onclick = function(event) {
    const modal = document.getElementById('courseModal');
    if (event.target === modal) {
        closeModal();
    }
}

// Fechar modal com ESC
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeModal();
        closeRatingModal();
    }
});

function filterCourses() {
    const category = document.getElementById('categoryFilter').value;
    const level = document.getElementById('levelFilter').value;
    const search = document.getElementById('searchInput').value.toLowerCase();
    
    let filtered = allCourses;
    
    if (category) {
        filtered = filtered.filter(c => c.category === category);
    }
    
    if (level) {
        filtered = filtered.filter(c => c.level === level);
    }
    
    if (search) {
        filtered = filtered.filter(c => 
            c.title.toLowerCase().includes(search) ||
            c.description.toLowerCase().includes(search) ||
            c.category.toLowerCase().includes(search) ||
            c.keywords.some(k => k.includes(search))
        );
    }
    
    displayCourses(filtered);
}

// Função para mostrar demonstração de ML
function showMLDemo() {
    const demoResults = document.getElementById('mlDemoResults');
    demoResults.style.display = 'block';
    demoResults.scrollIntoView({ behavior: 'smooth' });
    
    // Simular carregamento de recomendações
    setTimeout(() => {
        loadMLRecommendations();
    }, 500);
}

// Carregar recomendações de ML
function loadMLRecommendations() {
    const container = document.getElementById('mlRecommendedCourses');
    const recommendations = [
        {
            id: 1,
            title: 'Node.js e Express - Backend Completo',
            category: 'Backend',
            duration: '28h',
            rating: 4.9,
            match: 92,
            icon: '⚙️'
        },
        {
            id: 2,
            title: 'Docker e Kubernetes na Prática',
            category: 'DevOps',
            duration: '24h',
            rating: 4.8,
            match: 88,
            icon: '🐳'
        },
        {
            id: 3,
            title: 'PostgreSQL Avançado',
            category: 'Banco de Dados',
            duration: '20h',
            rating: 4.7,
            match: 85,
            icon: '🐘'
        }
    ];
    
    container.innerHTML = recommendations.map(course => `
        <div class="course-card">
            <div class="ml-badge">🎯 ${course.match}% Match</div>
            <div class="course-thumbnail large">
                <div class="course-icon">${course.icon}</div>
            </div>
            <div class="course-content">
                <span class="course-category">${course.category}</span>
                <h3>${course.title}</h3>
                <div class="course-meta">
                    <span>⏱️ ${course.duration}</span>
                    <span>⭐ ${course.rating}</span>
                </div>
                <button class="btn-primary" onclick="showCourseDetails(${course.id})">Ver Detalhes</button>
            </div>
        </div>
    `).join('');
}

// Verificar autenticação
function checkAuth() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
        updateHeaderForLoggedUser(user);
    }
}

// Atualizar header para usuário logado
function updateHeaderForLoggedUser(user) {
    const authButtons = document.getElementById('authButtons');
    const userMenuHeader = document.getElementById('userMenuHeader');
    const headerUserName = document.getElementById('headerUserName');
    
    if (authButtons && userMenuHeader) {
        authButtons.style.display = 'none';
        userMenuHeader.style.display = 'flex';
        
        if (headerUserName) {
            headerUserName.textContent = user.name || 'Usuário';
        }
    }
}

// Função de logout global
function logout() {
    if (confirm('Tem certeza que deseja sair?')) {
        localStorage.removeItem('user');
        alert('Logout realizado com sucesso!');
        window.location.href = 'index.html';
    }
}
