function showTab(tab) {
    // Remove active de todas as tabs e forms
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    
    // Adiciona active na tab clicada
    const clickedTab = Array.from(document.querySelectorAll('.auth-tab')).find(t => 
        t.textContent.toLowerCase().includes(tab)
    );
    if (clickedTab) {
        clickedTab.classList.add('active');
    }
    
    // Mostra o form correspondente
    const form = document.getElementById(tab + 'Form');
    if (form) {
        form.classList.add('active');
    }
}

function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Validação simples
    if (!email || !password) {
        alert('Por favor, preencha todos os campos!');
        return;
    }
    
    // Buscar usuário cadastrado
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        // Login bem-sucedido
        const userSession = {
            email: user.email,
            name: user.name,
            role: user.role || 'user',
            interests: user.interests || []
        };
        
        localStorage.setItem('user', JSON.stringify(userSession));
        alert('Login realizado com sucesso!');
        
        if (userSession.role === 'admin') {
            window.location.href = 'admin.html';
        } else {
            window.location.href = 'profile.html';
        }
    } else {
        alert('Email ou senha incorretos!');
    }
}

function handleRegister(event) {
    event.preventDefault();
    const name = document.getElementById('registerName').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('registerConfirmPassword').value;
    const interests = Array.from(document.getElementById('registerInterests').selectedOptions)
        .map(option => option.value);
    
    // Validações
    if (!name || !email || !password || !confirmPassword) {
        alert('Por favor, preencha todos os campos obrigatórios!');
        return;
    }
    
    if (password.length < 8) {
        alert('A senha deve ter no mínimo 8 caracteres!');
        return;
    }
    
    if (password !== confirmPassword) {
        alert('As senhas não coincidem!');
        return;
    }
    
    // Verificar se o email já existe
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const emailExists = users.find(u => u.email === email);
    
    if (emailExists) {
        alert('Este email já está cadastrado!');
        return;
    }
    
    // Criar novo usuário
    const newUser = {
        id: Date.now(), // ID único baseado no timestamp
        name: name,
        email: email,
        password: password, // Em produção, deve ser criptografado
        interests: interests,
        role: 'user',
        createdAt: new Date().toISOString()
    };
    
    // Adicionar à lista de usuários
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    // Fazer login automático
    const userSession = {
        email: newUser.email,
        name: newUser.name,
        interests: newUser.interests,
        role: 'user'
    };
    
    localStorage.setItem('user', JSON.stringify(userSession));
    
    alert(`Conta criada com sucesso! Bem-vindo(a), ${name}!`);
    window.location.href = 'profile.html';
}

function demoLogin(type) {
    if (type === 'admin') {
        const adminUser = {
            email: 'admin@cursos.com', 
            name: 'Administrador',
            role: 'admin'
        };
        localStorage.setItem('user', JSON.stringify(adminUser));
        alert('Login realizado com sucesso!');
        window.location.href = 'admin.html';
    } else {
        const demoUser = {
            email: 'usuario@cursos.com', 
            name: 'João Silva',
            role: 'user',
            interests: ['Programação', 'Backend', 'Cloud']
        };
        localStorage.setItem('user', JSON.stringify(demoUser));
        alert('Login realizado com sucesso!');
        window.location.href = 'profile.html';
    }
}

// Inicializar usuários demo no primeiro acesso
function initializeDemoUsers() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    // Se não há usuários, criar os usuários de teste
    if (users.length === 0) {
        const initialUsers = [
            {
                id: 1,
                name: 'Administrador',
                email: 'admin@cursos.com',
                password: 'admin123',
                role: 'admin',
                interests: [],
                createdAt: new Date().toISOString()
            },
            {
                id: 2,
                name: 'João Silva',
                email: 'usuario@cursos.com',
                password: 'senha123',
                role: 'user',
                interests: ['Programação', 'Backend', 'Cloud'],
                createdAt: new Date().toISOString()
            },
            {
                id: 3,
                name: 'Maria Santos',
                email: 'maria@cursos.com',
                password: 'senha123',
                role: 'user',
                interests: ['Frontend', 'Design', 'Mobile'],
                createdAt: new Date().toISOString()
            }
        ];
        
        localStorage.setItem('users', JSON.stringify(initialUsers));
    }
}

// Verificar parâmetro de URL para mostrar cadastro
window.addEventListener('DOMContentLoaded', () => {
    initializeDemoUsers();
    
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('mode') === 'register') {
        const registerTab = document.querySelectorAll('.auth-tab')[1];
        if (registerTab) {
            registerTab.click();
        }
    }
});
