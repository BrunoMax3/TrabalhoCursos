const API_URL = 'http://localhost:5000/api';

// Base de 50+ cursos diversos
const coursesData = [
    // Programação (18 cursos)
    { id: 1, title: 'JavaScript Completo - ES6+', category: 'programacao', instructor: 'João Silva', rating: 4.9, students: 15234, price: 149.90, duration: '45h', level: 'Iniciante', icon: '📜', tags: ['javascript', 'frontend', 'web'], isPopular: true, isNew: false },
    { id: 2, title: 'React.js - Do Zero ao Avançado', category: 'programacao', instructor: 'Maria Santos', rating: 4.8, students: 12456, price: 159.90, duration: '50h', level: 'Intermediário', icon: '⚛️', tags: ['react', 'frontend', 'spa'], isPopular: true },
    { id: 3, title: 'Node.js e Express - Backend Completo', category: 'programacao', instructor: 'Carlos Souza', rating: 4.9, students: 10987, price: 169.90, duration: '42h', level: 'Intermediário', icon: '⚙️', tags: ['nodejs', 'backend', 'api'], isPopular: true },
    { id: 4, title: 'Python para Iniciantes', category: 'programacao', instructor: 'Ana Costa', rating: 4.7, students: 18234, price: 129.90, duration: '35h', level: 'Iniciante', icon: '🐍', tags: ['python', 'programacao', 'basico'], isNew: true },
    { id: 5, title: 'TypeScript - JavaScript com Superpoderes', category: 'programacao', instructor: 'Pedro Lima', rating: 4.8, students: 8765, price: 139.90, duration: '28h', level: 'Intermediário', icon: '💙', tags: ['typescript', 'javascript', 'tipos'] },
    { id: 6, title: 'Vue.js 3 - Framework Progressivo', category: 'programacao', instructor: 'Juliana Rocha', rating: 4.7, students: 6543, price: 149.90, duration: '38h', level: 'Intermediário', icon: '💚', tags: ['vuejs', 'frontend', 'spa'] },
    { id: 7, title: 'Angular - Desenvolvimento Empresarial', category: 'programacao', instructor: 'Roberto Alves', rating: 4.6, students: 7890, price: 159.90, duration: '48h', level: 'Avançado', icon: '🔺', tags: ['angular', 'typescript', 'enterprise'] },
    { id: 8, title: 'Java Completo - POO e Spring Boot', category: 'programacao', instructor: 'Fernando Silva', rating: 4.8, students: 11234, price: 179.90, duration: '55h', level: 'Intermediário', icon: '☕', tags: ['java', 'spring', 'backend'], isPopular: true },
    { id: 9, title: 'C# e .NET Core - Desenvolvimento Moderno', category: 'programacao', instructor: 'Camila Dias', rating: 4.7, students: 8901, price: 169.90, duration: '52h', level: 'Intermediário', icon: '💜', tags: ['csharp', 'dotnet', 'backend'] },
    { id: 10, title: 'PHP Moderno e Laravel', category: 'programacao', instructor: 'Lucas Martins', rating: 4.6, students: 9876, price: 149.90, duration: '44h', level: 'Intermediário', icon: '🐘', tags: ['php', 'laravel', 'web'] },
    { id: 11, title: 'Go (Golang) - Programação Concorrente', category: 'programacao', instructor: 'Rafael Costa', rating: 4.8, students: 5432, price: 159.90, duration: '36h', level: 'Avançado', icon: '🔵', tags: ['golang', 'backend', 'performance'], isNew: true },
    { id: 12, title: 'Rust - Programação de Sistemas', category: 'programacao', instructor: 'Thiago Souza', rating: 4.7, students: 3456, price: 169.90, duration: '40h', level: 'Avançado', icon: '🦀', tags: ['rust', 'sistemas', 'performance'] },
    { id: 13, title: 'Kotlin para Android', category: 'programacao', instructor: 'Paula Oliveira', rating: 4.8, students: 7654, price: 159.90, duration: '46h', level: 'Intermediário', icon: '🤖', tags: ['kotlin', 'android', 'mobile'], isPopular: true },
    { id: 14, title: 'Swift e iOS Development', category: 'programacao', instructor: 'Bruno Santos', rating: 4.7, students: 6789, price: 169.90, duration: '48h', level: 'Intermediário', icon: '🍎', tags: ['swift', 'ios', 'mobile'] },
    { id: 15, title: 'Flutter - Apps Multiplataforma', category: 'programacao', instructor: 'Larissa Lima', rating: 4.9, students: 9012, price: 159.90, duration: '42h', level: 'Intermediário', icon: '📱', tags: ['flutter', 'dart', 'mobile'], isNew: true, isPopular: true },
    { id: 16, title: 'React Native - Apps Mobile com React', category: 'programacao', instructor: 'Diego Rocha', rating: 4.8, students: 8345, price: 159.90, duration: '44h', level: 'Intermediário', icon: '📲', tags: ['react-native', 'mobile', 'javascript'] },
    { id: 17, title: 'SQL e Banco de Dados Relacionais', category: 'programacao', instructor: 'Marcelo Dias', rating: 4.7, students: 12345, price: 129.90, duration: '32h', level: 'Iniciante', icon: '🗄️', tags: ['sql', 'database', 'mysql'] },
    { id: 18, title: 'MongoDB - Banco de Dados NoSQL', category: 'programacao', instructor: 'Fernanda Costa', rating: 4.6, students: 7890, price: 139.90, duration: '28h', level: 'Intermediário', icon: '🍃', tags: ['mongodb', 'nosql', 'database'] },

    // Design (12 cursos)
    { id: 19, title: 'UI/UX Design Completo com Figma', category: 'design', instructor: 'Beatriz Silva', rating: 4.9, students: 10234, price: 149.90, duration: '40h', level: 'Iniciante', icon: '🎨', tags: ['design', 'ux', 'ui', 'figma'], isPopular: true },
    { id: 20, title: 'Adobe Photoshop - Do Básico ao Avançado', category: 'design', instructor: 'Ricardo Santos', rating: 4.8, students: 14567, price: 139.90, duration: '38h', level: 'Iniciante', icon: '🖼️', tags: ['photoshop', 'design', 'edicao'] },
    { id: 21, title: 'Illustrator - Design Gráfico Profissional', category: 'design', instructor: 'Gabriela Lima', rating: 4.7, students: 8901, price: 139.90, duration: '36h', level: 'Intermediário', icon: '✏️', tags: ['illustrator', 'vetor', 'design'] },
    { id: 22, title: 'After Effects - Motion Graphics', category: 'design', instructor: 'André Costa', rating: 4.8, students: 7654, price: 159.90, duration: '44h', level: 'Intermediário', icon: '🎬', tags: ['after-effects', 'motion', 'animacao'], isNew: true },
    { id: 23, title: 'Design Thinking e Metodologias Ágeis', category: 'design', instructor: 'Patrícia Rocha', rating: 4.9, students: 9876, price: 129.90, duration: '24h', level: 'Iniciante', icon: '💡', tags: ['design-thinking', 'agile', 'metodologia'] },
    { id: 24, title: 'Prototipagem e Wireframes', category: 'design', instructor: 'Rodrigo Dias', rating: 4.7, students: 6543, price: 119.90, duration: '20h', level: 'Iniciante', icon: '📐', tags: ['prototipo', 'wireframe', 'ux'] },
    { id: 25, title: 'Design de Interfaces Mobile', category: 'design', instructor: 'Carla Santos', rating: 4.8, students: 8234, price: 139.90, duration: '32h', level: 'Intermediário', icon: '📱', tags: ['mobile', 'ui', 'app-design'] },
    { id: 26, title: 'Identidade Visual e Branding', category: 'design', instructor: 'Marcos Silva', rating: 4.7, students: 7012, price: 149.90, duration: '36h', level: 'Intermediário', icon: '🎭', tags: ['branding', 'identidade', 'marca'] },
    { id: 27, title: 'Web Design Responsivo', category: 'design', instructor: 'Julia Costa', rating: 4.8, students: 9345, price: 129.90, duration: '30h', level: 'Iniciante', icon: '💻', tags: ['web-design', 'responsivo', 'ui'], isNew: true },
    { id: 28, title: 'Design System - Criando Sistemas de Design', category: 'design', instructor: 'Felipe Alves', rating: 4.9, students: 5678, price: 159.90, duration: '28h', level: 'Avançado', icon: '📚', tags: ['design-system', 'ui', 'componentes'] },
    { id: 29, title: 'Tipografia e Hierarquia Visual', category: 'design', instructor: 'Amanda Lima', rating: 4.6, students: 4567, price: 99.90, duration: '18h', level: 'Iniciante', icon: '🔤', tags: ['tipografia', 'design', 'visual'] },
    { id: 30, title: 'Teoria das Cores aplicada ao Design', category: 'design', instructor: 'Leonardo Rocha', rating: 4.7, students: 5890, price: 89.90, duration: '16h', level: 'Iniciante', icon: '🌈', tags: ['cores', 'teoria', 'design'] },

    // Marketing (10 cursos)
    { id: 31, title: 'Marketing Digital Completo', category: 'marketing', instructor: 'Sandra Costa', rating: 4.8, students: 16789, price: 149.90, duration: '42h', level: 'Iniciante', icon: '📊', tags: ['marketing', 'digital', 'estrategia'], isPopular: true },
    { id: 32, title: 'SEO - Otimização para Mecanismos de Busca', category: 'marketing', instructor: 'Paulo Silva', rating: 4.7, students: 11234, price: 129.90, duration: '28h', level: 'Intermediário', icon: '🔍', tags: ['seo', 'google', 'marketing'] },
    { id: 33, title: 'Google Ads - Anúncios que Convertem', category: 'marketing', instructor: 'Renata Santos', rating: 4.8, students: 9876, price: 139.90, duration: '32h', level: 'Intermediário', icon: '💰', tags: ['google-ads', 'ppc', 'anuncios'] },
    { id: 34, title: 'Facebook e Instagram Ads Avançado', category: 'marketing', instructor: 'Gustavo Lima', rating: 4.9, students: 13456, price: 149.90, duration: '36h', level: 'Intermediário', icon: '📱', tags: ['facebook-ads', 'instagram', 'social'], isPopular: true },
    { id: 35, title: 'Marketing de Conteúdo e Copywriting', category: 'marketing', instructor: 'Vanessa Rocha', rating: 4.8, students: 10987, price: 129.90, duration: '30h', level: 'Iniciante', icon: '✍️', tags: ['conteudo', 'copy', 'escrita'], isNew: true },
    { id: 36, title: 'E-mail Marketing e Automação', category: 'marketing', instructor: 'Eduardo Dias', rating: 4.7, students: 8654, price: 119.90, duration: '24h', level: 'Intermediário', icon: '📧', tags: ['email', 'automacao', 'marketing'] },
    { id: 37, title: 'Growth Hacking - Crescimento Acelerado', category: 'marketing', instructor: 'Isabela Costa', rating: 4.9, students: 7890, price: 159.90, duration: '28h', level: 'Avançado', icon: '🚀', tags: ['growth', 'hacking', 'startup'] },
    { id: 38, title: 'Inbound Marketing e Funis de Vendas', category: 'marketing', instructor: 'Henrique Silva', rating: 4.8, students: 9123, price: 139.90, duration: '32h', level: 'Intermediário', icon: '🎯', tags: ['inbound', 'funil', 'vendas'] },
    { id: 39, title: 'Análise de Dados com Google Analytics', category: 'marketing', instructor: 'Tatiana Lima', rating: 4.7, students: 8456, price: 129.90, duration: '26h', level: 'Intermediário', icon: '📈', tags: ['analytics', 'dados', 'metricas'] },
    { id: 40, title: 'Tráfego Pago - Estratégias Avançadas', category: 'marketing', instructor: 'Vinícius Santos', rating: 4.8, students: 10234, price: 149.90, duration: '34h', level: 'Avançado', icon: '💸', tags: ['trafego', 'pago', 'ads'], isNew: true },

    // Negócios (8 cursos)
    { id: 41, title: 'Gestão de Projetos com Metodologias Ágeis', category: 'negocios', instructor: 'Cristina Alves', rating: 4.8, students: 12345, price: 149.90, duration: '36h', level: 'Intermediário', icon: '📋', tags: ['gestao', 'agile', 'scrum'], isPopular: true },
    { id: 42, title: 'Excel Avançado para Negócios', category: 'negocios', instructor: 'Maurício Costa', rating: 4.9, students: 18765, price: 99.90, duration: '28h', level: 'Intermediário', icon: '📊', tags: ['excel', 'planilhas', 'analise'], isPopular: true },
    { id: 43, title: 'Empreendedorismo e Startups', category: 'negocios', instructor: 'Daniela Silva', rating: 4.7, students: 9876, price: 139.90, duration: '32h', level: 'Iniciante', icon: '🚀', tags: ['empreendedorismo', 'startup', 'negocios'] },
    { id: 44, title: 'Finanças Pessoais e Investimentos', category: 'negocios', instructor: 'Alexandre Lima', rating: 4.8, students: 14567, price: 129.90, duration: '30h', level: 'Iniciante', icon: '💰', tags: ['financas', 'investimentos', 'dinheiro'] },
    { id: 45, title: 'Liderança e Gestão de Equipes', category: 'negocios', instructor: 'Mônica Rocha', rating: 4.9, students: 11234, price: 149.90, duration: '28h', level: 'Intermediário', icon: '👥', tags: ['lideranca', 'gestao', 'equipes'], isNew: true },
    { id: 46, title: 'Business Intelligence e Power BI', category: 'negocios', instructor: 'Sérgio Dias', rating: 4.8, students: 10987, price: 159.90, duration: '40h', level: 'Avançado', icon: '📊', tags: ['bi', 'powerbi', 'dados'] },
    { id: 47, title: 'Vendas e Negociação B2B', category: 'negocios', instructor: 'Adriana Santos', rating: 4.7, students: 8901, price: 139.90, duration: '26h', level: 'Intermediário', icon: '🤝', tags: ['vendas', 'negociacao', 'b2b'] },
    { id: 48, title: 'Gestão Financeira Empresarial', category: 'negocios', instructor: 'Roberto Costa', rating: 4.8, students: 9654, price: 149.90, duration: '34h', level: 'Avançado', icon: '💼', tags: ['financas', 'gestao', 'empresarial'] },

    // Dados e IA (7 cursos)
    { id: 49, title: 'Python para Data Science', category: 'dados', instructor: 'Luciana Silva', rating: 4.9, students: 13456, price: 179.90, duration: '50h', level: 'Intermediário', icon: '🐍', tags: ['python', 'data-science', 'analise'], isPopular: true, isNew: true },
    { id: 50, title: 'Machine Learning com Python', category: 'dados', instructor: 'Ricardo Lima', rating: 4.8, students: 10234, price: 189.90, duration: '55h', level: 'Avançado', icon: '🤖', tags: ['machine-learning', 'ia', 'python'], isPopular: true },
    { id: 51, title: 'Deep Learning e Redes Neurais', category: 'dados', instructor: 'Carolina Costa', rating: 4.9, students: 7890, price: 199.90, duration: '60h', level: 'Avançado', icon: '🧠', tags: ['deep-learning', 'neural', 'ia'] },
    { id: 52, title: 'Análise de Dados com Python e Pandas', category: 'dados', instructor: 'Fernando Santos', rating: 4.7, students: 11567, price: 149.90, duration: '38h', level: 'Intermediário', icon: '📊', tags: ['pandas', 'analise', 'python'] },
    { id: 53, title: 'Big Data e Apache Spark', category: 'dados', instructor: 'Mariana Rocha', rating: 4.6, students: 6789, price: 169.90, duration: '44h', level: 'Avançado', icon: '💾', tags: ['big-data', 'spark', 'hadoop'] },
    { id: 54, title: 'Visualização de Dados com Tableau', category: 'dados', instructor: 'Gustavo Dias', rating: 4.7, students: 8456, price: 139.90, duration: '30h', level: 'Intermediário', icon: '📈', tags: ['tableau', 'visualizacao', 'dados'] },
    { id: 55, title: 'Inteligência Artificial Generativa', category: 'dados', instructor: 'Beatriz Alves', rating: 4.9, students: 9876, price: 189.90, duration: '48h', level: 'Avançado', icon: '✨', tags: ['ia-generativa', 'gpt', 'ai'], isNew: true, isPopular: true },

    // Idiomas (6 cursos)
    { id: 56, title: 'Inglês do Zero ao Avançado', category: 'idiomas', instructor: 'Michael Johnson', rating: 4.8, students: 19234, price: 0, duration: '80h', level: 'Iniciante', icon: '🇺🇸', tags: ['ingles', 'idiomas', 'conversacao'], isFree: true, isPopular: true },
    { id: 57, title: 'Inglês para Negócios', category: 'idiomas', instructor: 'Sarah Williams', rating: 4.7, students: 12345, price: 149.90, duration: '40h', level: 'Intermediário', icon: '💼', tags: ['ingles', 'business', 'negocios'] },
    { id: 58, title: 'Espanhol Completo', category: 'idiomas', instructor: 'Carlos García', rating: 4.8, students: 10987, price: 0, duration: '70h', level: 'Iniciante', icon: '🇪🇸', tags: ['espanhol', 'idiomas', 'conversacao'], isFree: true },
    { id: 59, title: 'Francês para Iniciantes', category: 'idiomas', instructor: 'Marie Dubois', rating: 4.6, students: 7654, price: 129.90, duration: '50h', level: 'Iniciante', icon: '🇫🇷', tags: ['frances', 'idiomas', 'basico'] },
    { id: 60, title: 'Alemão Essencial', category: 'idiomas', instructor: 'Hans Mueller', rating: 4.7, students: 6543, price: 139.90, duration: '55h', level: 'Iniciante', icon: '🇩🇪', tags: ['alemao', 'idiomas', 'europeu'] },
    { id: 61, title: 'Mandarim para Negócios', category: 'idiomas', instructor: 'Li Wei', rating: 4.8, students: 5432, price: 149.90, duration: '60h', level: 'Intermediário', icon: '🇨🇳', tags: ['mandarim', 'chines', 'business'], isNew: true }
];

let allCourses = coursesData;
let displayedCourses = 12;
let currentFilter = 'todos';
let chatHistory = [];
let searchTimeout;

// Utilitário simples de escape
function sanitize(t){return t.replace(/[<>&]/g,m=>({ '<':'&lt;','>':'&gt;','&':'&amp;' }[m]));}

// Inicialização
window.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    renderCoursesSlice();
    updateLoadMoreButton();
    attachGlobalEvents();
});

// Anexar eventos globais
function attachGlobalEvents(){
    document.addEventListener('click',e=>{
        if(e.target.dataset.close==="true") closeChatIA();
    });
    document.addEventListener('keydown',e=>{
        if(e.key==="Escape") closeChatIA();
    });
    const searchInput=document.getElementById('searchInput');
    if(searchInput){
        searchInput.addEventListener('input',()=>{
            clearTimeout(searchTimeout);
            searchTimeout=setTimeout(()=>searchCourses(),250);
        });
    }
}

// Render parcial
function renderCoursesSlice(){
    let filtered=getFilteredCourses();
    displayCourses(filtered.slice(0,displayedCourses));
}

// Determinar conjunto filtrado
function getFilteredCourses(){
    switch(currentFilter){
        case 'populares': return allCourses.filter(c=>c.isPopular);
        case 'novos': return allCourses.filter(c=>c.isNew);
        case 'gratuitos': return allCourses.filter(c=>c.isFree||c.price===0);
        default:
            if(currentFilter!=='todos' && currentFilter) return allCourses.filter(c=>c.category===currentFilter);
            return allCourses;
    }
}

// Exibir cursos
function displayCourses(courses){
    const container=document.getElementById('coursesContainer');
    if(!container) return;
    if(!courses.length){
        container.innerHTML='<div class="no-results">Nenhum curso encontrado.</div>';
        return;
    }
    container.innerHTML=courses.map(course=>`
        <div class="course-card" data-id="${course.id}">
            <div class="course-badges">
                ${course.isNew?'<span class="badge badge-new">Novo</span>':''}
                ${course.isPopular?'<span class="badge badge-popular">Popular</span>':''}
                ${(course.isFree||course.price===0)?'<span class="badge badge-free">Grátis</span>':''}
            </div>
            <div class="course-icon-large">${sanitize(course.icon||'📚')}</div>
            <div class="course-content">
                <h3 class="course-title">${sanitize(course.title)}</h3>
                <p class="course-instructor">👨‍🏫 ${sanitize(course.instructor)}</p>
                <div class="course-stats">
                    <span>⭐ ${course.rating}</span>
                    <span>👥 ${course.students.toLocaleString('pt-BR')}</span>
                    <span>⏱️ ${course.duration}</span>
                </div>
                <div class="course-footer">
                    ${(course.price>0)?`<span class="price">R$ ${course.price.toFixed(2)}</span>`:`<span class="price-free">Gratuito</span>`}
                    <button class="btn-course" data-view="${course.id}">Ver Curso →</button>
                </div>
            </div>
        </div>
    `).join('');
    container.querySelectorAll('[data-view]').forEach(btn=>{
        btn.addEventListener('click',e=>{
            e.stopPropagation();
            viewCourse(parseInt(btn.dataset.view,10));
        });
    });
    container.querySelectorAll('.course-card').forEach(card=>{
        card.addEventListener('click',()=>viewCourse(parseInt(card.dataset.id,10)));
    });
}

// Busca
function searchCourses(){
    const val=(document.getElementById('searchInput')?.value||'').toLowerCase().trim();
    if(!val){ displayedCourses=12; renderCoursesSlice(); updateLoadMoreButton(); return; }
    const result=allCourses.filter(c=>
        c.title.toLowerCase().includes(val)||
        c.instructor.toLowerCase().includes(val)||
        c.category.toLowerCase().includes(val)||
        c.tags.some(t=>t.toLowerCase().includes(val))
    );
    displayCourses(result);
    document.getElementById('loadMoreBtn')?.style.setProperty('display','none');
}

// Filtro por tabs
function filterCourses(filter, evt){
    currentFilter=filter;
    displayedCourses=12;
    document.querySelectorAll('.filter-tab').forEach(b=>b.classList.remove('active'));
    if(evt) evt.currentTarget.classList.add('active');
    renderCoursesSlice();
    updateLoadMoreButton();
}

// Categoria
function filterByCategory(category){
    currentFilter=category;
    displayedCourses=12;
    renderCoursesSlice();
    updateLoadMoreButton();
    scrollToSection('courses');
}

// Load more
function loadMoreCourses(){
    displayedCourses+=12;
    renderCoursesSlice();
    updateLoadMoreButton();
}
function updateLoadMoreButton(){
    const btn=document.getElementById('loadMoreBtn');
    if(!btn) return;
    const total=getFilteredCourses().length;
    btn.style.display=displayedCourses>=total?'none':'block';
}

// Navegação suave
function scrollToSection(id){
    document.getElementById(id)?.scrollIntoView({behavior:'smooth'});
}

// Ver curso
function viewCourse(id){
    window.location.href=`course.html?id=${id}`;
}

// Autenticação
function checkAuth(){
    const token=localStorage.getItem('token');
    const user=JSON.parse(localStorage.getItem('user')||'{}');
    const loginBtn=document.getElementById('loginBtn');
    const profileBtn=document.getElementById('profileBtn');
    const headerUserName=document.getElementById('headerUserName');
    if(token && user.name){
        if(loginBtn) loginBtn.style.display='none';
        if(profileBtn){ profileBtn.style.display='flex'; }
        if(headerUserName) headerUserName.textContent=user.name;
    }else{
        if(loginBtn) loginBtn.style.display='block';
        if(profileBtn) profileBtn.style.display='none';
    }
}

// Chat IA
function openChatIA(){
    const modal=document.getElementById('chatModal');
    if(!modal) return;
    modal.style.display='flex';
    modal.setAttribute('aria-hidden','false');
    document.body.style.overflow='hidden';
    document.getElementById('chatInput')?.focus();
}
function closeChatIA(){
    const modal=document.getElementById('chatModal');
    if(!modal) return;
    modal.style.display='none';
    modal.setAttribute('aria-hidden','true');
    document.body.style.overflow='auto';
}
function handleChatEnter(e){
    if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); sendChatMessage(); }
}
async function sendChatMessage(){
    const input=document.getElementById('chatInput');
    if(!input) return;
    const message=input.value.trim();
    if(!message) return;
    
    const suggestionsEl = document.getElementById('chatSuggestions');
    if(suggestionsEl) suggestionsEl.classList.add('hidden');
    
    addChatMessage(message,'user');
    input.value='';
    input.disabled = true; // Desabilita enquanto processa
    
    const typingId=addTypingIndicator();
    
    try{
        const resp = await fetch(`${API_URL}/chat/ask`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message })
        });
        
        removeTypingIndicator(typingId);
        input.disabled = false;
        input.focus();
        
        if (!resp.ok) {
            throw new Error(`Erro ${resp.status}`);
        }
        
        const data = await resp.json();
        
        if (data.response) {
            addChatMessage(data.response, 'bot');
            chatHistory.push(
                { role: 'user', content: message },
                { role: 'assistant', content: data.response }
            );
            
            if (Array.isArray(data.suggestedCourses) && data.suggestedCourses.length) {
                addCourseSuggestions(data.suggestedCourses);
            }
        } else {
            throw new Error('Resposta inválida');
        }
        
    } catch(err) {
        removeTypingIndicator(typingId);
        input.disabled = false;
        input.focus();
        console.error('Chat error:', err);
        
        addChatMessage(
            'Desculpe, tive um problema de conexão! 😅\n\n' +
            'Mas estou aqui para ajudar! Pergunte sobre:\n' +
            '• Cursos de programação\n' +
            '• Design e UX\n' +
            '• Marketing digital\n' +
            '• Carreiras em tech',
            'bot'
        );
    }
}
function sendSuggestion(text){
    const input=document.getElementById('chatInput');
    if(!input) return;
    input.value=text;
    sendChatMessage();
}
function addChatMessage(msg, sender){
    const wrap=document.getElementById('chatMessages');
    if(!wrap) return;
    const div=document.createElement('div');
    div.className=`chat-message ${sender}`;
    div.innerHTML=`<div class="message-avatar">${sender==='user'?'👤':'🤖'}</div><div class="message-bubble">${sanitize(msg).replace(/\n/g,'<br>')}</div>`;
    wrap.appendChild(div);
    wrap.scrollTop=wrap.scrollHeight;
}
function addTypingIndicator(){
    const wrap=document.getElementById('chatMessages');
    const div=document.createElement('div');
    div.id='typing-indicator';
    div.className='chat-message bot';
    div.innerHTML='<div class="message-avatar">🤖</div><div class="message-bubble typing"><span></span><span></span><span></span></div>';
    wrap.appendChild(div);
    wrap.scrollTop=wrap.scrollHeight;
    return div.id;
}
function removeTypingIndicator(id){
    document.getElementById(id)?.remove();
}
function addCourseSuggestions(ids){
    const wrap=document.getElementById('chatMessages');
    const courses=allCourses.filter(c=>ids.includes(c.id));
    if(!courses.length) return;
    const cont=document.createElement('div');
    cont.className='course-suggestions';
    cont.innerHTML=`
        <div class="suggestions-header">📚 Recomendações:</div>
        ${courses.map(c=>`
            <div class="suggestion-card" data-course="${c.id}">
                <span class="suggestion-icon">${sanitize(c.icon||'📘')}</span>
                <div class="suggestion-info">
                    <strong>${sanitize(c.title)}</strong>
                    <span>⭐ ${c.rating} • ${c.duration}</span>
                </div>
            </div>
        `).join('')}
    `;
    wrap.appendChild(cont);
    cont.querySelectorAll('.suggestion-card').forEach(card=>{
        card.addEventListener('click',()=>viewCourse(parseInt(card.dataset.course,10)));
    });
    wrap.scrollTop=wrap.scrollHeight;
}
