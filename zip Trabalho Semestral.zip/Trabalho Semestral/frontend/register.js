const API_URL = 'http://localhost:5000/api';

document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const terms = document.getElementById('terms').checked;
    const submitBtn = e.target.querySelector('.btn-submit');
    
    if (!name || !email || !password) {
        alert('❌ Preencha todos os campos!');
        return;
    }
    
    if (password !== confirmPassword) {
        alert('❌ As senhas não coincidem!');
        return;
    }
    
    if (password.length < 6) {
        alert('❌ A senha deve ter no mínimo 6 caracteres!');
        return;
    }
    
    if (!terms) {
        alert('❌ Você precisa aceitar os termos de uso!');
        return;
    }
    
    submitBtn.disabled = true;
    submitBtn.textContent = 'Criando conta...';
    
    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password })
        });
        
        const data = await response.json();
        
        if (response.ok && data.token) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            alert('✅ Conta criada com sucesso!');
            window.location.href = 'index.html';
        } else {
            throw new Error(data.message || 'Erro ao criar conta');
        }
    } catch (error) {
        alert(`❌ ${error.message}`);
        submitBtn.disabled = false;
        submitBtn.textContent = 'Criar Conta';
    }
});
