// Configuração da API
const API_URL = 'http://localhost:5000/api';


async function safeFetch(url, options = {}, timeoutMs = 5000) {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeoutMs);
    try {
        const resp = await fetch(url, { ...options, signal: controller.signal });
        clearTimeout(id);
        return resp;
    } catch (e) {
        clearTimeout(id);
        throw e;
    }
}

function sanitize(text) {
    if (typeof text !== 'string') return '';
    return text.replace(/[<>&]/g, m => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[m]));
}

// Verificar se o backend está rodando
async function checkBackendConnection() {
    try {
        const response = await safeFetch(`${API_URL}/health`, { method: 'GET' }, 2000);
        return response.ok;
    } catch {
        return false;
    }
}

function showProfileSection(section, evt) {
    document.querySelectorAll('.profile-nav a').forEach(a => a.classList.remove('active'));
    document.querySelectorAll('.profile-section').forEach(s => s.classList.remove('active'));
    if (evt && evt.currentTarget) {
        evt.currentTarget.classList.add('active');
    }
    const el = document.getElementById('profile-' + section);
    if (el) el.classList.add('active');
}

function logout() {
    if (confirm('Tem certeza que deseja sair?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('userId');
        localStorage.removeItem('userRole');
        localStorage.removeItem('user');
        alert('Logout realizado com sucesso em CursosPlat!');
        window.location.href = 'index.html';
    }
}

// Carregar dados do usuário
window.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');

    if (token) {
        const backendOnline = await checkBackendConnection();
        if (backendOnline) {
            try {
                const user = await fetchUserFromDatabase(token);
                if (user) {
                    // NOVO: persistir usuário e role
                    localStorage.setItem('user', JSON.stringify(user));
                    if (user.role) localStorage.setItem('userRole', user.role);
                    updateUserInfo(user);
                    await loadUserCourses(user.id);
                    await loadPersonalizedRecommendations(user.id, user.interests);
                    console.log('✅ Usando dados do PostgreSQL (CursosPlat)');
                    // Verifica admin após carregar perfil
                    const ok = await checkAdminAvailability(user);
                    // NOVO: atualizar UI do painel admin
                    updateAdminUI(isAdmin(user), ok);
                    return;
                }
            } catch (error) {
                console.warn('Backend indisponível, usando dados locais (CursosPlat):', error?.message || error);
                localStorage.removeItem('token');
            }
        }
    }

    // Usar dados locais (modo padrão)
    loadLocalData();
    // Verifica admin com dados locais
    const localUser = JSON.parse(localStorage.getItem('user') || '{}');
    const ok = await checkAdminAvailability(localUser);
    updateAdminUI(isAdmin(localUser), ok);

    try {
        const params = new URLSearchParams(location.search);
        if (params.get('seedAdmin') === '1') {
            await seedAdminUser();
        }
    } catch (e) {
        console.warn('Seed admin falhou:', e?.message || e);
    }
});

function updateAdminUI(isAdminUser, adminOk) {
    const adminPanel = document.getElementById('adminPanel');
    const adminStatusEl = document.getElementById('adminStatus');
    if (adminPanel) {
        adminPanel.style.display = isAdminUser && adminOk ? 'block' : 'none';
    }
    if (adminStatusEl) {
        const msg = !isAdminUser
            ? 'Admin: usuário não é admin'
            : adminOk
                ? 'Admin: backend OK'
                : 'Admin: backend indisponível ou sem token';             
                createAdminUser({ 
                    name: 'Administrador', 
                    email: 'admin@cursosplat.com', 
                    password: 'admin123' 
                })
                .then(() => console.log('Admin registrado!'))
                .catch(err => console.error('Erro:', err.message))
                
                // Depois fazer login
                loginUser('admin@cursosplat.com', 'admin123')
        adminStatusEl.textContent = msg;
    }
}

// Carregar dados locais
function loadLocalData() {
    let user = null;
    try {
        user = JSON.parse(localStorage.getItem('user'));
    } catch {
        user = null;
    }
    if (!user) {
        user = {
            name: 'Visitante CursosPlat',
            email: 'visitante@demo.com',
            interests: ['Programação', 'Frontend', 'Backend']
        };
        localStorage.setItem('user', JSON.stringify(user));
    }
    updateUserInfo(user);
    loadLocalCourses();
    loadMockRecommendations();
    console.log('✅ Usando dados locais (CursosPlat)');
}

// Cursos locais
function loadLocalCourses() {
    const courses = [
        { id: 1, title: 'React.js - Do Zero ao Avançado', icon: '⚛️', progress: 65, duration: '40h', rating: 4.8 },
        { id: 2, title: 'Node.js e Express', icon: '⚙️', progress: 30, duration: '35h', rating: 4.9 },
        { id: 3, title: 'PostgreSQL Avançado', icon: '🗄️', progress: 15, duration: '28h', rating: 4.7 }
    ];
    displayUserCourses(courses);
}

// Buscar dados do usuário do PostgreSQL
async function fetchUserFromDatabase(token) {
    try {
        const response = await safeFetch(`${API_URL}/auth/profile`, { // alterado de /users/profile para /auth/profile
            method: 'GET',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' }
        }, 5000);
        if (!response.ok) throw new Error('Perfil não encontrado');
        const data = await response.json();
        console.log('✅ Perfil carregado via API (CursosPlat)');
        return data;
    } catch (e) {
        console.warn('fetchUserFromDatabase falhou (CursosPlat):', e.message);
        return null;
    }
}

// Carregar cursos do usuário do banco de dados
async function loadUserCourses(userId) {
    try {
        const token = localStorage.getItem('token');
        const response = await safeFetch(`${API_URL}/users/${userId}/courses`, {
            method: 'GET',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' }
        }, 5000);

        if (!response.ok) throw new Error('Falha ao buscar cursos');

        const courses = await response.json();
        displayUserCourses(Array.isArray(courses) && courses.length > 0 ? courses : getMockCourses());
    } catch (error) {
        console.warn('loadUserCourses fallback (CursosPlat):', error?.message || error);
        displayUserCourses(getMockCourses());
    }
}

function getMockCourses() {
    return [
        { id: 1, title: 'React.js - Do Zero ao Avançado', icon: '⚛️', progress: 65, duration: '40h', rating: 4.8 },
        { id: 2, title: 'Node.js e Express', icon: '⚙️', progress: 30, duration: '35h', rating: 4.9 }
    ];
}

// Exibir cursos do usuário (com sanitização e defaults)
function displayUserCourses(courses) {
    const coursesContainer = document.getElementById('userCoursesContainer');
    if (!coursesContainer) return;

    if (!Array.isArray(courses) || courses.length === 0) {
        coursesContainer.innerHTML = '<p>Você ainda não está matriculado em nenhum curso.</p>';
        return;
    }

    coursesContainer.innerHTML = courses.map(c => {
        const title = sanitize(c.title || 'Curso');
        const icon = sanitize(c.icon || '📚');
        const progress = Number.isFinite(c.progress) ? c.progress : 0;
        const duration = sanitize(c.duration || '—');
        const rating = sanitize(String(c.rating ?? '—'));
        const id = sanitize(String(c.id ?? '0'));

        return `
        <div class="course-card">
            <div class="course-thumbnail">
                <div class="course-icon">${icon}</div>
                <div class="progress-badge">${progress}%</div>
            </div>
            <div class="course-content">
                <h3>${title}</h3>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${progress}%"></div>
                </div>
                <div class="course-meta">
                    <span>⏱️ ${duration}</span>
                    <span>⭐ ${rating}</span>
                </div>
                <button class="btn-primary" onclick="window.location.href='course.html?id=${id}'">Continuar</button>
            </div>
        </div>`;
    }).join('');
}

function updateUserInfo(user) {
    const userNameElement = document.getElementById('userName');
    const userEmailElement = document.getElementById('userEmail');
    const welcomeNameElement = document.getElementById('welcomeName');
    const headerUserName = document.getElementById('headerUserName');

    if (!user || typeof user !== 'object') return;

    const name = user.name || 'Usuário CursosPlat';
    const email = user.email || '';

    if (userNameElement) userNameElement.textContent = name;
    if (userEmailElement) userEmailElement.textContent = email;
    if (welcomeNameElement) welcomeNameElement.textContent = name;
    if (headerUserName) headerUserName.textContent = name;
}

// Carregar recomendações do PostgreSQL baseadas em ML
async function loadPersonalizedRecommendations(userId, interests) {
    try {
        const token = localStorage.getItem('token');
        const response = await safeFetch(`${API_URL}/recommendations/${userId}`, {
            method: 'GET',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' }
        }, 5000);

        if (!response.ok) throw new Error('Falha ao buscar recomendações');

        const recommendations = await response.json();
        displayRecommendations(Array.isArray(recommendations) && recommendations.length > 0 ? recommendations : null);
    } catch (error) {
        console.warn('loadPersonalizedRecommendations fallback (CursosPlat):', error?.message || error);
        loadMockRecommendations();
    }
}

// Exibir recomendações do banco de dados (sanitização e defaults)
function displayRecommendations(recommendations) {
    if (!recommendations) {
        loadMockRecommendations();
        return;
    }

    const recommendedCourses = document.getElementById('recommendedCoursesContainer');
    if (!recommendedCourses) return;

    recommendedCourses.innerHTML = recommendations.map(course => {
        const title = sanitize(course.title || 'Curso recomendado');
        const icon = sanitize(course.icon || '📚');
        const description = sanitize(course.recommendation_reason || course.description || 'Recomendação personalizada pela IA');
        const duration = sanitize(course.duration || '—');
        const rating = sanitize(String(course.rating ?? '—'));
        const match = Number.isFinite(course.match_score) ? course.match_score : 90;
        const id = sanitize(String(course.id ?? '0'));

        return `
        <div class="course-card recommended">
            <div class="ml-badge">🎯 ${match}% Match – CursosPlat</div>
            <div class="course-thumbnail large">
                <div class="course-icon">${icon}</div>
            </div>
            <div class="course-content">
                <h3>${title}</h3>
                <p>${description}</p>
                <div class="course-meta">
                    <span>⏱️ ${duration}</span>
                    <span>⭐ ${rating}</span>
                </div>
                <button class="btn-primary" onclick="window.location.href='course.html?id=${id}'">Ver Curso</button>
            </div>
        </div>`;
    }).join('');
}


function loadMockRecommendations() {
    const recommendedCourses = document.getElementById('recommendedCoursesContainer');
    if (!recommendedCourses) return;

    const mockCourses = [
        { title: 'Vue.js 3 - Do Zero ao Avançado', description: 'Baseado no seu progresso em React.js', match: 95, duration: '32h', rating: 4.9, icon: '🎨' },
        { title: 'TypeScript na Prática', description: 'Complementa seu conhecimento em JavaScript', match: 88, duration: '24h', rating: 4.8, icon: '💻' },
        { title: 'Node.js e Express - Backend Completo', description: 'Perfeito para expandir suas habilidades', match: 92, duration: '28h', rating: 4.9, icon: '⚙️' }
    ];

    recommendedCourses.innerHTML = mockCourses.map(course => `
        <div class="course-card recommended">
            <div class="ml-badge">🎯 ${course.match}% Match – CursosPlat</div>
            <div class="course-thumbnail large">
                <div class="course-icon">${sanitize(course.icon)}</div>
            </div>
            <div class="course-content">
                <h3>${sanitize(course.title)}</h3>
                <p>${sanitize(course.description)}</p>
                <div class="course-meta">
                    <span>⏱️ ${sanitize(course.duration)}</span>
                    <span>⭐ ${sanitize(String(course.rating))}</span>
                </div>
                <button class="btn-primary">Ver Curso</button>
            </div>
        </div>
    `).join('');
}

// Detectar se usuário é admin
function isAdmin(user) {
    const role = (user && user.role) || localStorage.getItem('userRole');
    return String(role).toLowerCase() === 'admin';
}

// Verificar se parte de admin está funcionando
async function checkAdminAvailability(user) {
    const adminStatusEl = document.getElementById('adminStatus');
    const token = localStorage.getItem('token');
    const backendOnline = await checkBackendConnection();

    // Se não for admin, reporta rapidamente
    if (!isAdmin(user)) {
        const msg = 'Admin: usuário não é admin';
        console.info(msg);
        if (adminStatusEl) adminStatusEl.textContent = msg;
        return false;
    }

    // Tenta endpoint específico de admin (se existir)
    if (backendOnline && token) {
        try {
            const resp = await safeFetch(`${API_URL}/admin/health`, {
                method: 'GET',
                headers: { 'Authorization': `Bearer ${token}` }
            }, 3000);

            const ok = resp.ok;
            const msg = ok ? 'Admin: backend OK' : `Admin: backend com erro (${resp.status})`;
            console.info(msg);
            if (adminStatusEl) adminStatusEl.textContent = msg;
            return ok;
        } catch (e) {
            const msg = 'Admin: backend indisponível';
            console.warn(msg, e?.message || e);
            if (adminStatusEl) adminStatusEl.textContent = msg;
            return false;
        }
    } else {
        const msg = backendOnline ? 'Admin: sem token' : 'Admin: backend offline';
        console.info(msg);
        if (adminStatusEl) adminStatusEl.textContent = msg;
        return false;
    }
}

// Criar usuário (role pode ser 'admin' para criar admin)
async function createUserInDatabase({ name, email, password, role = 'user' }) {
    if (!name || !email || !password) throw new Error('name, email, password obrigatórios');
    const resp = await safeFetch(`${API_URL}/auth/register`, { // alterado de /users para /auth/register
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, role })
    }, 8000);
    if (!resp.ok) {
        const txt = await resp.text().catch(() => '');
        throw new Error(`Falha (${resp.status}): ${txt || resp.statusText}`);
    }
    const data = await resp.json();
    console.log('Usuário criado:', data);
    return data;
}

// Atalho específico para admin
async function createAdminUser({ name = 'Administrador', email, password }) {
    return createUserInDatabase({ name, email, password, role: 'admin' });
}

// NOVO: login de usuário (tenta /auth/login)
async function loginUser(email, password) {
    if (!email || !password) throw new Error('email e password obrigatórios');

    let data = null;
    try {
        const resp = await safeFetch(`${API_URL}/auth/login`, { // removido fallback /users/login
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        }, 8000);
        if (resp.ok) data = await resp.json();
    } catch {
        // nada
    }

    if (!data) throw new Error('Falha no login: verifique credenciais ou endpoint');

    const token = data.token || data.accessToken || data.jwt || null;
    const user = data.user || data.profile || data || null;

    if (!token || !user) throw new Error('Resposta de login inválida');

    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    if (user.role) localStorage.setItem('userRole', user.role);

    updateUserInfo(user);
    await loadUserCourses(user.id || user.userId || user._id);
    await loadPersonalizedRecommendations(user.id || user.userId || user._id, user.interests);

    const adminOk = await checkAdminAvailability(user);
    updateAdminUI(isAdmin(user), adminOk);

    console.log('✅ Login realizado com sucesso (CursosPlat)');
    return { token, user };
}

// NOVO: criar admin (se permitido) e fazer login; se já existir, apenas faz login
async function seedAdminUser({ email = 'admin@cursosplat.com', password = 'admin123', name = 'Administrador' } = {}) {
    try {
        const created = await createAdminUser({ email, password, name });
        console.log('Admin criado:', created);
    } catch (e) {
        // Se já existir ou backend exigir privilégios, tenta só logar
        console.warn('Não foi possível criar admin, tentando login:', e?.message || e);
    }
    // Tenta login mesmo se a criação falhar
    return loginUser(email, password);
}

window.isAdmin = isAdmin;
window.checkAdminAvailability = checkAdminAvailability;
window.updateAdminUI = updateAdminUI;
window.createUserInDatabase = createUserInDatabase;
window.createAdminUser = createAdminUser;
window.loginUser = loginUser;
window.seedAdminUser = seedAdminUser;
