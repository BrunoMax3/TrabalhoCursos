import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/courses.css';

const CourseFilter = () => {
  const [courses, setCourses] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [selectedArea, setSelectedArea] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/courses');
      setCourses(response.data);
      setFiltered(response.data);
    } catch (error) {
      console.error('Erro ao buscar cursos:', error);
    }
  };

  const handleFilter = () => {
    let result = courses;

    if (selectedArea) {
      result = result.filter(c => c.area === selectedArea);
    }
    if (selectedLevel) {
      result = result.filter(c => c.level === selectedLevel);
    }
    if (searchTerm) {
      result = result.filter(c =>
        c.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFiltered(result);
  };

  useEffect(() => {
    handleFilter();
  }, [selectedArea, selectedLevel, searchTerm]);

  return (
    <div className="courses-container">
      <div className="filters">
        <input
          type="text"
          placeholder="🔍 Pesquisar cursos..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        <select value={selectedArea} onChange={(e) => setSelectedArea(e.target.value)}>
          <option value="">Todas as áreas</option>
          <option value="TI">TI</option>
          <option value="Marketing">Marketing</option>
          <option value="Saúde">Saúde</option>
          <option value="Negócios">Negócios</option>
        </select>

        <select value={selectedLevel} onChange={(e) => setSelectedLevel(e.target.value)}>
          <option value="">Todos os níveis</option>
          <option value="iniciante">Iniciante</option>
          <option value="intermediário">Intermediário</option>
          <option value="avançado">Avançado</option>
        </select>
      </div>

      <div className="courses-grid">
        {filtered.map(course => (
          <div key={course.id} className="course-card">
            <img src={course.imageUrl || 'placeholder.png'} alt={course.title} />
            <h3>{course.title}</h3>
            <p className="instructor">👨‍🏫 {course.instructor}</p>
            <p className="description">{course.description}</p>
            <div className="course-info">
              <span className="area">📌 {course.area}</span>
              <span className="level">{course.level}</span>
            </div>
            <div className="course-footer">
              <span className="price">R$ {course.price}</span>
              <span className="rating">⭐ {course.rating || 'Novo'}</span>
            </div>
            <button className="btn-enroll">Inscrever-se</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CourseFilter;
