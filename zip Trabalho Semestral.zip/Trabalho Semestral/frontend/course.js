const API_URL = 'http://localhost:5000/api';

// Base de dados dos cursos
const coursesData = [
    // Programação
    { id: 1, title: 'JavaScript Completo - ES6+', category: 'programacao', instructor: 'João Silva', rating: 4.9, students: 15234, price: 149.90, duration: '45h', level: 'Iniciante', icon: '📜', tags: ['javascript', 'frontend', 'web'], description: 'Aprenda JavaScript moderno do zero ao avançado. Domine ES6+, programação assíncrona, DOM, APIs e muito mais.', requirements: ['Computador com internet', 'Vontade de aprender'], learnings: ['Fundamentos do JavaScript', 'ES6+ (Arrow Functions, Destructuring, etc)', 'Manipulação do DOM', 'Fetch API e Promises', 'Async/Await', 'Projeto prático completo'] },
    { id: 2, title: 'React.js - Do Zero ao Avançado', category: 'programacao', instructor: 'Maria Santos', rating: 4.8, students: 12456, price: 159.90, duration: '50h', level: 'Intermediário', icon: '⚛️', tags: ['react', 'frontend', 'spa'], description: 'Domine React.js e construa aplicações web modernas e escaláveis. Aprenda Hooks, Context API, Redux e muito mais.', requirements: ['JavaScript intermediário', 'HTML e CSS'], learnings: ['Components e Props', 'State e Lifecycle', 'Hooks (useState, useEffect)', 'Context API', 'React Router', 'Redux para gerenciamento de estado'] },
    { id: 3, title: 'Node.js e Express - Backend Completo', category: 'programacao', instructor: 'Carlos Souza', rating: 4.9, students: 10987, price: 169.90, duration: '42h', level: 'Intermediário', icon: '⚙️', tags: ['nodejs', 'backend', 'api'], description: 'Crie APIs RESTful profissionais com Node.js e Express. Autenticação, banco de dados, deploy e muito mais.', requirements: ['JavaScript básico'], learnings: ['Node.js fundamentos', 'Express framework', 'APIs RESTful', 'Autenticação JWT', 'Banco de dados (MongoDB/PostgreSQL)', 'Deploy em produção'] },
    { id: 4, title: 'Python para Iniciantes', category: 'programacao', instructor: 'Ana Costa', rating: 4.7, students: 18234, price: 129.90, duration: '35h', level: 'Iniciante', icon: '🐍', tags: ['python', 'programacao', 'basico'], description: 'Aprenda Python do zero. A linguagem mais versátil para iniciantes. Web, automação, data science e mais.', requirements: ['Nenhum conhecimento prévio'], learnings: ['Sintaxe básica do Python', 'Estruturas de dados', 'Funções e módulos', 'POO (Orientação a Objetos)', 'Manipulação de arquivos', 'Projetos práticos'] },
    { id: 5, title: 'TypeScript - JavaScript com Superpoderes', category: 'programacao', instructor: 'Pedro Lima', rating: 4.8, students: 8765, price: 139.90, duration: '28h', level: 'Intermediário', icon: '💙', tags: ['typescript', 'javascript', 'tipos'], description: 'Adicione tipagem estática ao JavaScript. Aumente a qualidade e manutenibilidade do seu código.', requirements: ['JavaScript intermediário'], learnings: ['Tipos básicos', 'Interfaces e Types', 'Generics', 'Decorators', 'TypeScript com React', 'Configuração avançada'] },
    
    // Design
    { id: 19, title: 'UI/UX Design Completo com Figma', category: 'design', instructor: 'Beatriz Silva', rating: 4.9, students: 10234, price: 149.90, duration: '40h', level: 'Iniciante', icon: '🎨', tags: ['design', 'ux', 'ui', 'figma'], description: 'Aprenda a criar interfaces incríveis com Figma. Design System, protótipos interativos e handoff para devs.', requirements: ['Criatividade', 'Computador'], learnings: ['Fundamentos de UX/UI', 'Figma completo', 'Protótipos interativos', 'Design System', 'Componentes reutilizáveis', 'Handoff para desenvolvedores'] },
    { id: 20, title: 'Adobe Photoshop - Do Básico ao Avançado', category: 'design', instructor: 'Ricardo Santos', rating: 4.8, students: 14567, price: 139.90, duration: '38h', level: 'Iniciante', icon: '🖼️', tags: ['photoshop', 'design', 'edicao'], description: 'Domine o Photoshop e crie artes incríveis. Edição de fotos, manipulação, design gráfico e mais.', requirements: ['Adobe Photoshop instalado'], learnings: ['Interface e ferramentas', 'Layers e máscaras', 'Ajustes de cor', 'Manipulação de fotos', 'Efeitos especiais', 'Projetos profissionais'] },
    
    // Marketing
    { id: 31, title: 'Marketing Digital Completo', category: 'marketing', instructor: 'Sandra Costa', rating: 4.8, students: 16789, price: 149.90, duration: '42h', level: 'Iniciante', icon: '📊', tags: ['marketing', 'digital', 'estrategia'], description: 'Aprenda todas as estratégias de marketing digital. SEO, Ads, redes sociais, e-mail marketing e mais.', requirements: ['Vontade de aprender'], learnings: ['Fundamentos do marketing', 'SEO e SEM', 'Google Ads', 'Facebook/Instagram Ads', 'E-mail Marketing', 'Análise de métricas'] },
    { id: 32, title: 'SEO - Otimização para Mecanismos de Busca', category: 'marketing', instructor: 'Paulo Silva', rating: 4.7, students: 11234, price: 129.90, duration: '28h', level: 'Intermediário', icon: '🔍', tags: ['seo', 'google', 'marketing'], description: 'Aprenda a rankear sites no Google. Técnicas on-page, off-page, link building e análise de concorrência.', requirements: ['Conhecimento básico de sites'], learnings: ['SEO On-Page', 'SEO Off-Page', 'Link Building', 'Pesquisa de palavras-chave', 'Google Search Console', 'Análise de concorrentes'] },
    
    // Dados
    { id: 49, title: 'Python para Data Science', category: 'dados', instructor: 'Luciana Silva', rating: 4.9, students: 13456, price: 179.90, duration: '50h', level: 'Intermediário', icon: '🐍', tags: ['python', 'data-science', 'analise'], description: 'Análise de dados com Python. Pandas, NumPy, visualização e machine learning básico.', requirements: ['Python básico'], learnings: ['Pandas e NumPy', 'Visualização de dados', 'Análise exploratória', 'Limpeza de dados', 'Estatística aplicada', 'ML básico'] },
    { id: 50, title: 'Machine Learning com Python', category: 'dados', instructor: 'Ricardo Lima', rating: 4.8, students: 10234, price: 189.90, duration: '55h', level: 'Avançado', icon: '🤖', tags: ['machine-learning', 'ia', 'python'], description: 'Aprenda algoritmos de Machine Learning. Regressão, classificação, clustering e neural networks.', requirements: ['Python e matemática básica'], learnings: ['Algoritmos de ML', 'Scikit-learn', 'Regressão e classificação', 'Clustering', 'Neural Networks', 'Projetos reais'] },
    
    // Negócios
    { id: 42, title: 'Excel Avançado para Negócios', category: 'negocios', instructor: 'Maurício Costa', rating: 4.9, students: 18765, price: 99.90, duration: '28h', level: 'Intermediário', icon: '📊', tags: ['excel', 'planilhas', 'analise'], description: 'Domine o Excel e aumente sua produtividade. Fórmulas avançadas, tabelas dinâmicas, macros e dashboards.', requirements: ['Excel básico'], learnings: ['Fórmulas avançadas', 'Tabelas dinâmicas', 'Gráficos profissionais', 'Macros e VBA', 'Dashboards', 'Análise de dados'] },
    { id: 46, title: 'Business Intelligence e Power BI', category: 'negocios', instructor: 'Sérgio Dias', rating: 4.8, students: 10987, price: 159.90, duration: '40h', level: 'Avançado', icon: '📊', tags: ['bi', 'powerbi', 'dados'], description: 'Transforme dados em insights com Power BI. Dashboards interativos, DAX, modelagem de dados e mais.', requirements: ['Conhecimento de dados'], learnings: ['Interface do Power BI', 'Importação de dados', 'Modelagem', 'DAX avançado', 'Dashboards interativos', 'Publicação e compartilhamento'] },
    
    // SQL/Banco de Dados
    { id: 17, title: 'SQL e Banco de Dados Relacionais', category: 'programacao', instructor: 'Marcelo Dias', rating: 4.7, students: 12345, price: 129.90, duration: '32h', level: 'Iniciante', icon: '🗄️', tags: ['sql', 'database', 'mysql'], description: 'Aprenda SQL do zero. Queries, JOINs, subqueries, otimização e boas práticas.', requirements: ['Lógica básica'], learnings: ['SQL básico e avançado', 'JOINs e subqueries', 'Índices e performance', 'Stored Procedures', 'Triggers', 'Normalização'] },
    { id: 52, title: 'Análise de Dados com Python e Pandas', category: 'dados', instructor: 'Fernando Santos', rating: 4.7, students: 11567, price: 149.90, duration: '38h', level: 'Intermediário', icon: '📊', tags: ['pandas', 'analise', 'python'], description: 'Análise e manipulação de dados com Pandas. Data cleaning, transformação e visualização.', requirements: ['Python básico'], learnings: ['Pandas fundamentos', 'Data cleaning', 'Transformação de dados', 'Análise exploratória', 'Visualização', 'Projetos práticos'] },
    
    // Idiomas
    { id: 56, title: 'Inglês do Zero ao Avançado', category: 'idiomas', instructor: 'Michael Johnson', rating: 4.8, students: 19234, price: 0, duration: '80h', level: 'Iniciante', icon: '🇺🇸', tags: ['ingles', 'idiomas', 'conversacao'], isFree: true, description: 'Aprenda inglês completo gratuitamente. Gramática, conversação, listening e reading.', requirements: ['Vontade de aprender'], learnings: ['Gramática básica', 'Vocabulário essencial', 'Conversação', 'Listening', 'Reading', 'Writing'] },
    { id: 58, title: 'Espanhol Completo', category: 'idiomas', instructor: 'Carlos García', rating: 4.8, students: 10987, price: 0, duration: '70h', level: 'Iniciante', icon: '🇪🇸', tags: ['espanhol', 'idiomas', 'conversacao'], isFree: true, description: 'Curso completo de espanhol gratuito. Do básico ao avançado com foco em conversação.', requirements: ['Nenhum'], learnings: ['Gramática espanhola', 'Vocabulário', 'Conversação', 'Pronúncia', 'Cultura hispânica', 'Certificado'] }
];

// Carregar curso ao iniciar página
window.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    loadCourse();
});

function checkAuth() {
    const token = localStorage.getItem('token');
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const loginBtn = document.getElementById('loginBtn');
    const profileBtn = document.getElementById('profileBtn');
    const headerUserName = document.getElementById('headerUserName');
    
    if (token && user.name) {
        if (loginBtn) loginBtn.style.display = 'none';
        if (profileBtn) profileBtn.style.display = 'flex';
        if (headerUserName) headerUserName.textContent = user.name;
    }
}

function loadCourse() {
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = parseInt(urlParams.get('id'), 10);
    
    if (!courseId) {
        window.location.href = 'index.html';
        return;
    }
    
    const course = coursesData.find(c => c.id === courseId);
    
    if (!course) {
        alert('Curso não encontrado!');
        window.location.href = 'index.html';
        return;
    }
    
    displayCourse(course);
}

function displayCourse(course) {
    // Título e info básica
    document.getElementById('courseIcon').textContent = course.icon || '📚';
    document.getElementById('courseTitle').textContent = course.title;
    document.getElementById('courseInstructor').textContent = `👨‍🏫 ${course.instructor}`;
    document.getElementById('courseRating').textContent = `⭐ ${course.rating}`;
    document.getElementById('courseStudents').textContent = `👥 ${course.students.toLocaleString('pt-BR')} alunos`;
    document.getElementById('courseDuration').textContent = `⏱️ ${course.duration}`;
    document.getElementById('courseLevel').textContent = `📊 ${course.level}`;
    
    // Preço
    const priceEl = document.getElementById('coursePrice');
    if (course.price === 0 || course.isFree) {
        priceEl.textContent = 'Gratuito';
        priceEl.classList.add('price-free');
    } else {
        priceEl.textContent = `R$ ${course.price.toFixed(2)}`;
    }
    
    // Descrição
    document.getElementById('courseDescription').textContent = course.description || 'Curso completo e prático.';
    
    const learningList = document.getElementById('learningList');
    if (course.learnings && course.learnings.length > 0) {
        learningList.innerHTML = course.learnings.map(item => `<li>✓ ${item}</li>`).join('');
    } else {
        learningList.innerHTML = '<li>✓ Conteúdo prático e completo</li><li>✓ Exemplos reais</li><li>✓ Projetos práticos</li>';
    }
    
    // Currículo (módulos)
    const curriculum = document.getElementById('curriculum');
    curriculum.innerHTML = `
        <div class="module">
            <h4>📌 Módulo 1: Introdução</h4>
            <p>Fundamentos e conceitos básicos</p>
        </div>
        <div class="module">
            <h4>📌 Módulo 2: Prática</h4>
            <p>Aplicação dos conhecimentos</p>
        </div>
        <div class="module">
            <h4>📌 Módulo 3: Avançado</h4>
            <p>Conceitos avançados e boas práticas</p>
        </div>
        <div class="module">
            <h4>📌 Módulo 4: Projeto Final</h4>
            <p>Projeto prático completo</p>
        </div>
    `;
    
    // Instrutor
    document.getElementById('instructorName').textContent = course.instructor;
    document.getElementById('instructorBio').textContent = `Expert em ${course.category} com anos de experiência prática.`;
    
    // Tags
    const tagsEl = document.getElementById('courseTags');
    if (course.tags && course.tags.length > 0) {
        tagsEl.innerHTML = course.tags.map(tag => `<span class="tag">${tag}</span>`).join('');
    }
    
    // Requisitos
    const reqEl = document.getElementById('courseRequirements');
    if (course.requirements && course.requirements.length > 0) {
        reqEl.innerHTML = course.requirements.map(req => `<li>${req}</li>`).join('');
    } else {
        reqEl.innerHTML = '<li>Vontade de aprender</li><li>Computador com internet</li>';
    }
    
    // Botão matricular
    document.getElementById('enrollBtn').onclick = () => enrollCourse(course);
}

function enrollCourse(course) {
    const token = localStorage.getItem('token');
    
    if (!token) {
        alert('Faça login para se matricular no curso!');
        window.location.href = 'login.html';
        return;
    }
    
    // Simular matrícula
    alert(`✅ Matrícula realizada com sucesso!\n\nCurso: ${course.title}\n\nAcesse seu perfil para começar a estudar.`);
    window.location.href = 'profile.html';
}
