const API_URL = 'http://localhost:5000/api';

document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    const userRole = localStorage.getItem('userRole');
    
    // ADMIN REQUER LOGIN OBRIGATÓRIO
    if (!token) {
        alert('Você precisa fazer login como administrador para acessar esta página.');
        window.location.href = 'login.html';
        return;
    }
    
    if (userRole !== 'admin') {
        alert('Acesso negado. Apenas administradores podem acessar esta página.');
        window.location.href = 'index.html';
        return;
    }
    
    await loadUsers();
    await loadCourses();
});

async function loadUsers() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/admin/users`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!response.ok) throw new Error('Erro ao carregar usuários');
        
        const users = await response.json();
        displayUsers(users);
        
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao carregar usuários');
    }
}

function displayUsers(users) {
    const tbody = document.querySelector('#usersTable tbody');
    if (!tbody) return;
    
    tbody.innerHTML = users.map(user => `
        <tr>
            <td>${user.id}</td>
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>
                <span class="badge ${user.role === 'admin' ? 'badge-admin' : 'badge-user'}">
                    ${user.role}
                </span>
            </td>
            <td>${user.course_count || 0}</td>
            <td>${new Date(user.created_at).toLocaleDateString('pt-BR')}</td>
            <td>
                <button onclick="toggleRole(${user.id}, '${user.role}')" class="btn-sm">
                    ${user.role === 'admin' ? 'Tornar User' : 'Tornar Admin'}
                </button>
                <button onclick="deleteUser(${user.id})" class="btn-sm btn-danger">Deletar</button>
            </td>
        </tr>
    `).join('');
}

async function toggleRole(userId, currentRole) {
    const newRole = currentRole === 'admin' ? 'user' : 'admin';
    
    if (!confirm(`Deseja alterar o papel deste usuário para ${newRole}?`)) {
        return;
    }
    
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/admin/users/${userId}/role`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ role: newRole })
        });
        
        if (!response.ok) throw new Error('Erro ao atualizar papel');
        
        alert('Papel atualizado com sucesso!');
        await loadUsers();
        
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao atualizar papel');
    }
}

async function deleteUser(userId) {
    if (!confirm('Tem certeza que deseja deletar este usuário?')) {
        return;
    }
    
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/admin/users/${userId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!response.ok) throw new Error('Erro ao deletar usuário');
        
        alert('Usuário deletado com sucesso!');
        await loadUsers();
        
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao deletar usuário');
    }
}

async function loadCourses() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/admin/courses`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!response.ok) throw new Error('Erro ao carregar cursos');
        
        const courses = await response.json();
        displayCourses(courses);
        
    } catch (error) {
        console.error('Erro:', error);
    }
}

function displayCourses(courses) {
    const tbody = document.querySelector('#coursesTable tbody');
    if (!tbody) return;
    
    tbody.innerHTML = courses.map(course => `
        <tr>
            <td>${course.id}</td>
            <td>${course.icon} ${course.title}</td>
            <td>${course.category}</td>
            <td>${course.duration}</td>
            <td>${course.rating}</td>
            <td>${course.enrolled_count || 0}</td>
            <td>
                <button class="btn-sm">Editar</button>
                <button class="btn-sm btn-danger">Deletar</button>
            </td>
        </tr>
    `).join('');
}

function showAdminSection(section) {
    document.querySelectorAll('.admin-nav a').forEach(a => a.classList.remove('active'));
    document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
    
    event.target.classList.add('active');
    document.getElementById('admin-' + section).classList.add('active');
    
    const titles = {
        'dashboard': 'Dashboard',
        'courses': 'Gerenciar Cursos',
        'users': 'Gerenciar Usuários',
        'reviews': 'Gerenciar Avaliações',
        'analytics': 'Estatísticas',
        'ml-settings': 'Configurações de Machine Learning'
    };
    
    document.getElementById('adminTitle').textContent = titles[section];
}

function openCourseModal(mode, courseId = null) {
    document.getElementById('courseFormModal').style.display = 'block';
    document.getElementById('courseModalTitle').textContent = 
        mode === 'create' ? 'Adicionar Novo Curso' : 'Editar Curso';
    
    if (mode === 'edit' && courseId) {
        // Carregar dados do curso
        console.log('Editing course:', courseId);
    }
}

function closeCourseModal() {
    document.getElementById('courseFormModal').style.display = 'none';
    document.getElementById('courseForm').reset();
}

function saveCourse(event) {
    event.preventDefault();
    
    const courseData = {
        name: document.getElementById('courseName').value,
        description: document.getElementById('courseDescription').value,
        category: document.getElementById('courseCategory').value,
        level: document.getElementById('courseLevel').value,
        duration: document.getElementById('courseDuration').value,
        price: document.getElementById('coursePrice').value
    };
    
    console.log('Saving course:', courseData);
    
    // Aqui faria a chamada para API
    alert('Curso salvo com sucesso!');
    closeCourseModal();
}

function editCourse(id) {
    openCourseModal('edit', id);
}

function deleteCourse(id) {
    if (confirm('Tem certeza que deseja excluir este curso?')) {
        console.log('Deleting course:', id);
        alert('Curso excluído com sucesso!');
    }
}

function viewUser(id) {
    alert('Visualizando usuário ID: ' + id);
}

function editUser(id) {
    alert('Editando usuário ID: ' + id);
}

function exportUsers() {
    alert('Exportando lista de usuários...');
}

// Fechar modal ao clicar fora
window.onclick = function(event) {
    const modal = document.getElementById('courseFormModal');
    if (event.target == modal) {
        closeCourseModal();
    }
}
