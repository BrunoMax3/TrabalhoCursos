const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Log de todas as requisições (para debug)
app.use((req, res, next) => {
    console.log(`${req.method} ${req.path}`);
    if (req.body && Object.keys(req.body).length > 0) {
        console.log('Body:', req.body);
    }
    next();
});

// Importar rotas
const authRoutes = require('./routes/auth');
const chatRoutes = require('./routes/chat');

// Rotas da API (ANTES dos arquivos estáticos)
app.use('/api/auth', authRoutes);
app.use('/api/chat', chatRoutes);

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'API CursosPlat funcionando' });
});

// Rota principal da API
app.get('/api', (req, res) => {
    res.json({
        name: 'CursosPlat API',
        version: '1.0.0',
        status: 'online',
        endpoints: {
            health: '/api/health',
            auth: {
                login: 'POST /api/auth/login',
                register: 'POST /api/auth/register',
                profile: 'GET /api/auth/profile'
            },
            chat: {
                ask: 'POST /api/chat/ask'
            }
        },
        documentation: 'https://github.com/seu-usuario/cursosplat'
    });
});

// Servir arquivos estáticos do frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// Rota catch-all para SPA (deve ser a ÚLTIMA)
app.get('*', (req, res) => {
    // Se for uma rota da API que não existe, retorna erro JSON
    if (req.path.startsWith('/api')) {
        console.log('❌ Rota não encontrada:', req.path);
        return res.status(404).json({ message: 'Rota não encontrada' });
    }
    // Caso contrário, serve o index.html
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Tratamento de erros global
app.use((err, req, res, next) => {
    console.error('❌ Erro no servidor:', err);
    res.status(500).json({ 
        message: 'Erro interno do servidor',
        error: err.message
    });
});

// Iniciar servidor
const PORT = 5000;
app.listen(PORT, () => {
    console.log('\n🚀 ========================================');
    console.log(`✅ Servidor CursosPlat rodando!`);
    console.log(`📡 API: http://localhost:${PORT}/api`);
    console.log(`🌐 Frontend: http://localhost:${PORT}`);
    console.log(`💬 Chat: http://localhost:${PORT}/api/chat/ask`);
    console.log('🚀 ========================================\n');
});
