import express, { Router, Request, Response } from 'express';
import OpenAI from 'openai';

const router = Router();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * @swagger
 * /api/chatbot/chat:
 *   post:
 *     summary: Envia mensagem ao ChatBot
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               message:
 *                 type: string
 *               userId:
 *                 type: string
 */
router.post('/chat', async (req: Request, res: Response) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      console.error('OPENAI_API_KEY não configurada');
      return res.status(500).json({ error: 'OPENAI_API_KEY não configurada' });
    }

    const { message, userId } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Campo "message" é obrigatório e deve ser string' });
    }

    const systemPrompt = `Você é um assistente amigável de uma plataforma de cursos online.
    Sua missão é ajudar usuários a encontrar o curso perfeito.
    Faça perguntas sobre interesses, experiência e objetivos.
    Recomende cursos baseado no perfil.
    Seja entusiasmado e use emojis ocasionalmente.`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
      temperature: 0.7,
      max_tokens: 500
    });

    const botResponse = completion.choices?.[0]?.message?.content ?? null;

    res.json({ response: botResponse, userId });
  } catch (error) {
    console.error('Erro ao processar /chat:', error);
    res.status(500).json({ error: 'Erro ao processar mensagem do ChatBot' });
  }
});

/**
 * Rota de teste para checar integração com OpenAI sem enviar payload do cliente.
 * Usa uma mensagem curta e retorna o texto recebido da OpenAI.
 */
router.get('/chat/test', async (_req: Request, res: Response) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      console.error('OPENAI_API_KEY não configurada');
      return res.status(500).json({ ok: false, error: 'OPENAI_API_KEY não configurada' });
    }

    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: 'Você é um assistente para teste.' },
        { role: 'user', content: 'Responda apenas: pong' }
      ],
      max_tokens: 10
    });

    const text = completion.choices?.[0]?.message?.content ?? null;
    res.json({ ok: true, text });
  } catch (error) {
    console.error('Erro ao processar /chat/test:', error);
    res.status(500).json({ ok: false, error: 'Erro ao testar integração com OpenAI' });
  }
});

/**
 * POST /api/chatbot
 * body: { message: string, userId?: string }
 */
router.post('/', (req: Request, res: Response) => {
  const { message } = req.body ?? {};
  if (!message || typeof message !== 'string') {
    return res.status(400).json({ erro: "Campo 'message' é obrigatório" });
  }

  // Lógica de exemplo: aqui você integra com modelo/recomendações reais
  const reply = `Recebi sua mensagem: "${message}"`;
  const recommendations = [
    { id: 1, title: "Introdução ao JavaScript", level: "Iniciante", score: 0.92 },
    { id: 2, title: "TypeScript para Backend", level: "Intermediário", score: 0.88 }
  ];

  return res.json({ reply, recommendations });
});

export default router;
