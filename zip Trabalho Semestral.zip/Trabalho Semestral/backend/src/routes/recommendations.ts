import express, { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

/**
 * @swagger
 * /api/recommendations/{userId}:
 *   get:
 *     summary: Obtém recomendações personalizadas para o usuário
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 */
router.get('/:userId', async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;

    // Buscar perfil e histórico do usuário
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { completedCourses: true, favorites: true }
    });

    if (!user) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    // Lógica simplificada de recomendação
    const completedAreas = user.completedCourses.map((c: any) => c.area);
    const recommendedCourses = await prisma.course.findMany({
      where: {
        area: { in: completedAreas },
        id: { notIn: user.completedCourses.map((c: any) => c.id) }
      },
      take: 5
    });

    res.json({
      recommendations: recommendedCourses,
      basedOn: completedAreas
    });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao gerar recomendações' });
  }
});

/**
 * @swagger
 * /api/recommendations:
 *   get:
 *     summary: Obtém todas as recomendações
 */
router.get('/', (req, res) => {
  // Exemplo de resposta
  res.json([
    { id: 1, curso: 'Node.js Básico', recomendado: true },
    { id: 2, curso: 'React Avançado', recomendado: false }
  ]);
});

export default router;
