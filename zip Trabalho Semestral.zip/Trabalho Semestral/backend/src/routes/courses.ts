import express, { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

/**
 * @swagger
 * /api/courses:
 *   get:
 *     summary: Lista todos os cursos
 *     parameters:
 *       - in: query
 *         name: area
 *         schema:
 *           type: string
 *         description: Filtrar por área (TI, Marketing, Saúde, etc)
 *       - in: query
 *         name: level
 *         schema:
 *           type: string
 *         description: Nível (iniciante, intermediário, avançado)
 *     responses:
 *       200:
 *         description: Lista de cursos
 */
router.get('/', async (req: Request, res: Response) => {
  try {
    const { area, level, search } = req.query;
    const courses = await prisma.course.findMany({
      where: {
        AND: [
          area ? { area: String(area) } : {},
          level ? { level: String(level) } : {},
          search ? { title: { contains: String(search), mode: 'insensitive' } } : {}
        ]
      }
    });
    res.json(courses);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar cursos' });
  }
});

/**
 * @swagger
 * /api/courses/{id}:
 *   get:
 *     summary: Obtém detalhes de um curso
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 */
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const course = await prisma.course.findUnique({
      where: { id: req.params.id },
      include: { reviews: true }
    });
    res.json(course);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar curso' });
  }
});

/**
 * @swagger
 * /api/courses:
 *   post:
 *     summary: Cria um novo curso (admin)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 */
router.post('/', async (req: Request, res: Response) => {
  try {
    const { title, description, area, level, price, instructor } = req.body;
    const course = await prisma.course.create({
      data: { title, description, area, level, price, instructor }
    });
    res.status(201).json(course);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao criar curso' });
  }
});

export default router;
