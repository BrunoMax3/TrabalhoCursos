const express = require('express');
const router = express.Router();
const courses = require('../data/courses-data');

function analyzeMessage(message) {
  const messageLower = message.toLowerCase();
  
  const intents = {
    level: null,
    topics: [],
    categories: []
  };
  
  // Detectar nível
  if (messageLower.match(/iniciante|começando|básico|zero|nunca|aprender|primeiro/)) {
    intents.level = 'Iniciante';
  } else if (messageLower.match(/intermediário|meio|já sei|experiência|algum conhecimento/)) {
    intents.level = 'Intermediário';
  } else if (messageLower.match(/avançado|expert|profundo|dominar|master/)) {
    intents.level = 'Avançado';
  }
  
  // Detectar categorias e tópicos expandidos
  const categoryMap = {
    'Programação': ['programação', 'programar', 'código', 'coding', 'desenvolv'],
    'Data Science': ['data science', 'ciência de dados', 'análise de dados', 'dados'],
    'IA': ['ia', 'inteligência artificial', 'machine learning', 'ml', 'deep learning', 'neural'],
    'Cloud': ['cloud', 'nuvem', 'aws', 'azure', 'gcp', 'google cloud'],
    'DevOps': ['devops', 'ci/cd', 'pipeline', 'kubernetes', 'docker', 'containers'],
    'Segurança': ['segurança', 'security', 'hacking', 'pentest', 'vulnerabilidades'],
    'Mobile': ['mobile', 'app', 'aplicativo', 'android', 'ios', 'react native', 'flutter'],
    'Design': ['design', 'ux', 'ui', 'interface', 'experiência'],
    'IoT': ['iot', 'arduino', 'raspberry', 'eletrônica', 'hardware', 'sensores'],
    'Blockchain': ['blockchain', 'bitcoin', 'ethereum', 'crypto', 'criptografia'],
    'Banco de Dados': ['banco de dados', 'database', 'sql', 'mongodb', 'postgresql'],
    'Frontend': ['frontend', 'front-end', 'react', 'vue', 'angular', 'web'],
    'Backend': ['backend', 'back-end', 'api', 'servidor', 'node'],
    'QA': ['qa', 'teste', 'testing', 'qualidade'],
    'Redes': ['redes', 'networking', 'tcp', 'ip'],
    'Big Data': ['big data', 'spark', 'hadoop'],
    'Data Engineering': ['data engineering', 'engenharia de dados', 'etl']
  };
  
  for (const [category, keywords] of Object.entries(categoryMap)) {
    if (keywords.some(kw => messageLower.includes(kw))) {
      intents.categories.push(category);
    }
  }
  
  // Detectar tópicos específicos
  const topicMap = {
    'javascript': ['javascript', 'js'],
    'typescript': ['typescript', 'ts'],
    'python': ['python'],
    'react': ['react'],
    'node': ['node', 'nodejs'],
    'java': ['java'],
    'swift': ['swift'],
    'flutter': ['flutter', 'dart']
  };
  
  for (const [topic, keywords] of Object.entries(topicMap)) {
    if (keywords.some(kw => messageLower.includes(kw))) {
      intents.topics.push(topic);
    }
  }
  
  return intents;
}

function calculateRelevance(course, intents, message) {
  let score = 0;
  const messageLower = message.toLowerCase();
  
  // Match de nível (peso 25%)
  if (intents.level && course.level === intents.level) {
    score += 0.25;
  }
  
  // Match de categoria (peso 40%)
  if (intents.categories.length > 0) {
    const categoryMatches = intents.categories.filter(cat => 
      course.category.toLowerCase().includes(cat.toLowerCase()) || 
      cat.toLowerCase().includes(course.category.toLowerCase())
    );
    score += (categoryMatches.length / Math.max(intents.categories.length, 1)) * 0.4;
  }
  
  // Match de tópicos (peso 20%)
  if (intents.topics.length > 0) {
    const topicMatches = intents.topics.filter(topic => 
      course.keywords.some(kw => kw.includes(topic))
    );
    score += (topicMatches.length / Math.max(intents.topics.length, 1)) * 0.2;
  }
  
  // Match de keywords (peso 15%)
  const keywordMatches = course.keywords.filter(kw => 
    messageLower.includes(kw)
  );
  score += (keywordMatches.length / Math.max(course.keywords.length, 1)) * 0.15;
  
  return Math.min(score, 1.0);
}

function generateReply(intents, recommendations) {
  let reply = "Olá! ";
  
  if (recommendations.length === 0) {
    return reply + "Desculpe, não encontrei cursos que correspondam exatamente à sua busca. Pode me dar mais detalhes sobre o que você gostaria de aprender? Temos cursos de programação, data science, cloud, mobile, segurança, IoT e muito mais!";
  }
  
  if (intents.level) {
    reply += `Encontrei cursos de nível ${intents.level} `;
  } else {
    reply += "Encontrei alguns cursos ";
  }
  
  if (intents.categories.length > 0) {
    reply += `de ${intents.categories.join(', ')} `;
  }
  
  if (intents.topics.length > 0) {
    reply += `focados em ${intents.topics.join(', ')} `;
  }
  
  reply += `que podem te ajudar! Veja as ${recommendations.length} melhores recomendações:`;
  
  return reply;
}

router.post('/', (req, res) => {
  const { message, userId } = req.body;

  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'Mensagem inválida' });
  }

  if (!userId || typeof userId !== 'string') {
    return res.status(400).json({ error: 'userId inválido' });
  }

  const intents = analyzeMessage(message);

  const recommendations = courses
    .map(course => {
      const score = calculateRelevance(course, intents, message);
      const reasons = [];
      
      if (intents.level && course.level === intents.level) {
        reasons.push(`Nível ${course.level}`);
      }
      
      if (intents.categories.length > 0) {
        reasons.push(`Categoria: ${course.category}`);
      }
      
      if (intents.topics.length > 0) {
        const topicMatches = intents.topics.filter(topic => 
          course.keywords.some(kw => kw.includes(topic))
        );
        if (topicMatches.length > 0) {
          reasons.push(`Tópicos: ${topicMatches.join(', ')}`);
        }
      }
      
      return {
        id: course.id,
        title: course.title,
        level: course.level,
        category: course.category,
        score: parseFloat(score.toFixed(2)),
        reason: reasons.length > 0 ? reasons.join(' | ') : 'Match com seus interesses',
        price: course.price,
        rating: course.rating,
        students: course.students
      };
    })
    .filter(rec => rec.score > 0.15)
    .sort((a, b) => b.score - a.score)
    .slice(0, 6);

  const reply = generateReply(intents, recommendations);

  res.json({
    reply,
    recommendations,
    detectedIntents: intents
  });
});

module.exports = router;
