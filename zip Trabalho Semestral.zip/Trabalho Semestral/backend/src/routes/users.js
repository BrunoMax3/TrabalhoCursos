const express = require('express');
const router = express.Router();

// Mock de usuários
let users = [
  {
    id: 1,
    name: "Pedro Alves",
    email: "pedro@example.com",
    interests: ["javascript", "frontend"],
    level: "Iniciante"
  }
];

// GET /api/users
router.get('/', (req, res) => {
  res.json(users);
});

// POST /api/users
router.post('/', (req, res) => {
  const { name, email, interests } = req.body;
  
  if (!name || !email) {
    return res.status(400).json({ error: 'Nome e email são obrigatórios' });
  }
  
  const newUser = {
    id: users.length + 1,
    name,
    email,
    interests: interests || [],
    level: "Iniciante"
  };
  
  users.push(newUser);
  res.status(201).json(newUser);
});

module.exports = router;
