const express = require('express');
const router = express.Router();

// GET /api/recommendations/:userId
router.get('/:userId', (req, res) => {
  const { userId } = req.params;
  
  // Mock de recomendações baseadas no perfil do usuário
  const recommendations = [
    { courseId: 1, relevanceScore: 0.92 },
    { courseId: 3, relevanceScore: 0.85 },
    { courseId: 2, relevanceScore: 0.78 }
  ];
  
  res.json(recommendations);
});

module.exports = router;
