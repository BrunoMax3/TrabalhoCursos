// Arquivo auxiliar para compartilhar dados de cursos entre módulos
// (Este é o mesmo array de courses do courses.js)

module.exports = require('./courses');
