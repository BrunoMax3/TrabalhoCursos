import express from "express";
import cors from "cors";
import "dotenv/config";
import swaggerUi from "swagger-ui-express";
import fs from "fs";
import path from "path";

// Logger customizado (deve vir antes de ser usado)
const logger = {
  info: (msg: string) => console.log(`ℹ️  [INFO] ${new Date().toISOString()} - ${msg}`),
  error: (msg: string) => console.error(`❌ [ERRO] ${new Date().toISOString()} - ${msg}`),
  success: (msg: string) => console.log(`✅ [SUCESSO] ${new Date().toISOString()} - ${msg}`),
  warn: (msg: string) => console.warn(`⚠️  [AVISO] ${new Date().toISOString()} - ${msg}`)
};

// Validar variáveis de ambiente críticas
const requiredEnvVars = ['NODE_ENV'];
const missingEnvVars = requiredEnvVars.filter(envVar => !process.env[envVar]);

if (missingEnvVars.length > 0) {
  logger.warn(`Variáveis de ambiente não definidas: ${missingEnvVars.join(', ')}`);
}

// Importar rotas com tratamento de erro
let courseRoutes, userRoutes, chatbotRoutes, recommendationRoutes;

try {
  courseRoutes = require('./routes/courses').default;
  userRoutes = require('./routes/users').default;
  chatbotRoutes = require('./routes/chatbot').default;
  recommendationRoutes = require('./routes/recommendations').default;
  logger.success('Rotas importadas com sucesso');
} catch (error: any) {
  logger.error(`Erro ao importar rotas: ${error.message}`);
  process.exit(1);
}

// Carregar swagger.json de forma segura (substitui o import direto)
let swaggerDocument: any = {};
try {
  const candidates = [
    path.join(__dirname, 'swagger.json'),               // runtime (dist ou src)
    path.join(__dirname, '..', 'swagger.json'),         // caso esteja um nível acima
    path.join(process.cwd(), 'swagger.json'),           // cwd do processo
    path.join(process.cwd(), 'src', 'swagger.json')     // durante dev com ts-node
  ];

  const found = candidates.find(p => {
    try { return fs.existsSync(p); } catch { return false; }
  });

  if (!found) throw new Error(`swagger.json não encontrado em: ${candidates.join(', ')}`);

  logger.info(`Carregando swagger.json de: ${found}`);
  const content = fs.readFileSync(found, 'utf8');
  const parsed = JSON.parse(content);

  if (parsed.openapi || parsed.swagger) {
    swaggerDocument = parsed;
    logger.success('Swagger JSON carregado com sucesso');
  } else {
    logger.warn('swagger.json carregado, mas sem campo "openapi" ou "swagger". Usando especificação fallback mínima.');
    swaggerDocument = {
      openapi: '3.0.0',
      info: { title: 'API (fallback)', version: '1.0.0', description: 'Fallback gerado porque swagger.json não continha versão válida.' },
      paths: {}
    };
  }
} catch (err: any) {
  logger.warn(`Não foi possível carregar swagger.json: ${err.message}. Usando especificação fallback mínima.`);
  swaggerDocument = {
    openapi: '3.0.0',
    info: { title: 'API (fallback)', version: '1.0.0', description: 'Fallback gerado porque swagger.json não pôde ser lido.' },
    paths: {}
  };
}

const app = express();
const PORT = process.env.PORT ?? 5000;

// Middleware
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  credentials: true
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Middleware de logging de requisições
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path}`);
  next();
});

// Swagger Configuration
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// manter 
app.get('/apii-docs', (_req, res) => {
  res.redirect(301, '/api-docs');
});

// Rota de documentação alternativa
app.get('/docs', (req, res) => {
  res.redirect('/api-docs');
});

// Routes
app.use('/api/courses', courseRoutes);
app.use('/api/users', userRoutes);
app.use('/api/chatbot', chatbotRoutes);
app.use('/api/recommendations', recommendationRoutes);

app.set('json spaces', 2);

// Health Check (com log)
app.get('/health', (req, res) => {
  logger.info(`GET /health recebido de ${req.ip}`);
  res.status(200).json({
    status: 'API operacional',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    ambiente: process.env.NODE_ENV || 'development'
  });
});

// Rota raiz com informações da API
app.get('/', (req, res) => {
  res.json({
    mensagem: 'Bem-vindo à Plataforma de Cursos API',
    versao: '1.0.0',
    docs: `http://localhost:${PORT}/api-docs`,
    endpoints: {
      cursos: '/api/courses',
      usuarios: '/api/users',
      chatbot: '/api/chatbot',
      recomendacoes: '/api/recommendations',
      saude: '/health'
    }
  });
});

// Middleware de tratamento de erros 404
app.use((req, res) => {
  res.status(404).json({
    erro: 'Rota não encontrada',
    caminho: req.path,
    metodo: req.method,
    dica: 'Verifique a URL ou acesse /api-docs para ver todos os endpoints disponíveis'
  });
});

// Middleware de tratamento de erros global
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  logger.error(err.message || 'Erro desconhecido');
  
  const statusCode = err.statusCode || 500;
  const mensagem = err.message || 'Erro interno do servidor';

  res.status(statusCode).json({
    erro: mensagem,
    statusCode,
    timestamp: new Date().toISOString(),
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// Inicialização do servidor com tratamento de erros
const server = app.listen(PORT, () => {
  logger.success(`Servidor iniciado na porta ${PORT}`);
  logger.info(`📚 Documentação Swagger: http://localhost:${PORT}/api-docs`);
  logger.info(`🏥 Health Check: http://localhost:${PORT}/health`);
  logger.info(`🚀 Ambiente: ${process.env.NODE_ENV || 'development'}`);
});

// Tratamento de erros não capturados
process.on('unhandledRejection', (reason, promise) => {
  logger.error(`Promise rejeitada não tratada: ${reason}`);
});

process.on('uncaughtException', (error) => {
  logger.error(`Exceção não capturada: ${error.message}`);
  process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.warn('Sinal SIGTERM recebido. Encerrando servidor gracefully...');
  server.close(() => {
    logger.success('Servidor encerrado com sucesso');
    process.exit(0);
  });
});

export default app;
