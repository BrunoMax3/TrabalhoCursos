const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// banco de dados simulado
const users = [
    {
        id: 1,
        name: 'Admin',
        email: process.env.ADMIN_EMAIL || 'admin@cursosplat.com',
        password: process.env.ADMIN_PASSWORD_HASH || '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
        role: 'admin',
        interests: ['Programação', 'Gestão']
    },
    {
        id: 2,
        name: 'João Silva',
        email: 'joao@teste.com',
        password: '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
        role: 'student',
        interests: ['React', 'JavaScript', 'Frontend']
    }
];

let userIdCounter = users.length + 1;

// Registro de novo usuário
router.post('/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;
        
        // Validações
        if (!name || !email || !password) {
            return res.status(400).json({ message: 'Todos os campos são obrigatórios' });
        }
        
        if (password.length < 6) {
            return res.status(400).json({ message: 'Senha deve ter no mínimo 6 caracteres' });
        }
        
        // Verificar se email já existe
        const existingUser = users.find(u => u.email === email);
        if (existingUser) {
            return res.status(400).json({ message: 'Email já cadastrado' });
        }
        
        // Hash da senha
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Criar novo usuário
        const newUser = {
            id: userIdCounter++,
            name,
            email,
            password: hashedPassword,
            role: 'student',
            interests: [],
            createdAt: new Date()
        };
        
        users.push(newUser);
        
        // Gerar token
        const token = jwt.sign(
            { id: newUser.id, email: newUser.email, role: newUser.role },
            process.env.JWT_SECRET || 'seu_secret_key_aqui',
            { expiresIn: '7d' }
        );
        
        res.status(201).json({
            message: 'Usuário criado com sucesso',
            token,
            user: {
                id: newUser.id,
                name: newUser.name,
                email: newUser.email,
                role: newUser.role
            }
        });
        
    } catch (error) {
        console.error('Erro no registro:', error);
        res.status(500).json({ message: 'Erro ao criar usuário' });
    }
});

// Login
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        // Validações
        if (!email || !password) {
            return res.status(400).json({ message: 'Email e senha são obrigatórios' });
        }
        
        // Buscar usuário
        const user = users.find(u => u.email === email);
        if (!user) {
            return res.status(401).json({ message: 'Email ou senha inválidos' });
        }
        
        // Verificar senha
        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
            return res.status(401).json({ message: 'Email ou senha inválidos' });
        }
        
        // Gerar token
        const token = jwt.sign(
            { id: user.id, email: user.email, role: user.role },
            process.env.JWT_SECRET || 'seu_secret_key_aqui',
            { expiresIn: '7d' }
        );
        
        res.json({
            message: 'Login realizado com sucesso',
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role,
                interests: user.interests
            }
        });
        
    } catch (error) {
        console.error('Erro no login:', error);
        res.status(500).json({ message: 'Erro ao fazer login' });
    }
});

// Middleware de autenticação
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
        return res.status(401).json({ message: 'Token não fornecido' });
    }
    
    jwt.verify(token, process.env.JWT_SECRET || 'seu_secret_key_aqui', (err, user) => {
        if (err) {
            return res.status(403).json({ message: 'Token inválido' });
        }
        req.user = user;
        next();
    });
};

// Rota protegida - Perfil do usuário
router.get('/profile', authenticateToken, (req, res) => {
    const user = users.find(u => u.id === req.user.id);
    
    if (!user) {
        return res.status(404).json({ message: 'Usuário não encontrado' });
    }
    
    res.json({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        interests: user.interests
    });
});

// Atualizar perfil
router.put('/profile', authenticateToken, async (req, res) => {
    try {
        const { name, interests } = req.body;
        const user = users.find(u => u.id === req.user.id);
        
        if (!user) {
            return res.status(404).json({ message: 'Usuário não encontrado' });
        }
        
        if (name) user.name = name;
        if (interests) user.interests = interests;
        
        res.json({
            message: 'Perfil atualizado com sucesso',
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role,
                interests: user.interests
            }
        });
        
    } catch (error) {
        console.error('Erro ao atualizar perfil:', error);
        res.status(500).json({ message: 'Erro ao atualizar perfil' });
    }
});

module.exports = router;
