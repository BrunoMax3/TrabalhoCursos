const express = require('express');
const router = express.Router();

// Log para debug
console.log('✅ Rota de chat carregada');

// Função auxiliar
function normalizeText(text) {
    return text.toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .trim();
}

// Função para verificar palavras-chave
function containsKeyword(text, keywords) {
    const normalized = normalizeText(text);
    return keywords.some(keyword => normalized.includes(normalizeText(keyword)));
}

router.post('/ask', (req, res) => {
    console.log('📩 Chat recebido:', req.body);
    
    try {
        const { message } = req.body;
        
        if (!message || typeof message !== 'string' || message.trim().length === 0) {
            return res.json({ 
                response: 'Por favor, envie uma mensagem válida. 😊',
                suggestedCourses: []
            });
        }
        
        const userMessage = message.trim();
        let response = '';
        let suggestedCourses = [];
        
        // Banco de dados + trabalho
        if (containsKeyword(userMessage, ['banco', 'entrevista', 'trabalhar']) && 
            containsKeyword(userMessage, ['dados', 'database', 'sql'])) {
            response = `🏦 **Preparação para Trabalhar em Bancos**\n\n` +
                `Para passar em entrevistas:\n\n` +
                `**SQL (ESSENCIAL):**\n` +
                `• Queries complexas\n` +
                `• Stored Procedures\n` +
                `• Otimização\n` +
                `• Transações\n\n` +
                `**Tecnologias:**\n` +
                `1. Oracle Database\n` +
                `2. SQL Server\n` +
                `3. PostgreSQL\n\n` +
                `💼 Salários: R$ 6k - 20k+`;
            suggestedCourses = [17, 42, 46, 52];
        }
        // Design
        else if (containsKeyword(userMessage, ['design', 'ui', 'ux', 'figma'])) {
            response = `🎨 **Design valorizado!**\n\n` +
                `**Trilha:**\n` +
                `1. UI/UX com Figma\n` +
                `2. Design Thinking\n` +
                `3. Prototipagem\n\n` +
                `💼 R$ 6k - 15k`;
            suggestedCourses = [19, 20, 23];
        }
        // Programação
        else if (containsKeyword(userMessage, ['programacao', 'programar', 'codigo'])) {
            response = `💻 **Programação!**\n\n` +
                `**Iniciantes:**\n` +
                `• JavaScript\n` +
                `• Python\n\n` +
                `**Avançado:**\n` +
                `• React.js\n` +
                `• Node.js\n\n` +
                `💰 R$ 3k - 30k+`;
            suggestedCourses = [1, 2, 3, 4];
        }
        // React/Frontend
        else if (containsKeyword(userMessage, ['react', 'frontend'])) {
            response = `⚛️ **Frontend!**\n\n` +
                `1. JavaScript ES6+\n` +
                `2. React.js\n` +
                `3. TypeScript`;
            suggestedCourses = [1, 2, 5];
        }
        // Backend
        else if (containsKeyword(userMessage, ['backend', 'node', 'api'])) {
            response = `⚙️ **Backend!**\n\n` +
                `• Node.js + Express\n` +
                `• PostgreSQL\n` +
                `• APIs REST`;
            suggestedCourses = [3, 8, 17];
        }
        // IA/Dados
        else if (containsKeyword(userMessage, ['dados', 'ia', 'machine'])) {
            response = `🤖 **IA é o futuro!**\n\n` +
                `1. Python Data Science\n` +
                `2. Machine Learning\n` +
                `3. Deep Learning\n\n` +
                `🚀 R$ 10k - 30k+`;
            suggestedCourses = [49, 50, 51, 55];
        }
        // Marketing
        else if (containsKeyword(userMessage, ['marketing', 'seo', 'ads'])) {
            response = `📊 **Marketing Digital!**\n\n` +
                `• Marketing Digital\n` +
                `• SEO\n` +
                `• Google Ads\n\n` +
                `💰 R$ 5k - 18k`;
            suggestedCourses = [31, 32, 33];
        }
        // Carreiras
        else if (containsKeyword(userMessage, ['carreira', 'trabalho', 'salario'])) {
            response = `💼 **Carreiras 2024**\n\n` +
                `1. Full Stack - R$ 8k-20k\n` +
                `2. Data Science - R$ 10k-30k\n` +
                `3. UX Designer - R$ 6k-15k\n` +
                `4. Marketing - R$ 5k-18k`;
            suggestedCourses = [1, 2, 49, 19];
        }
        // Iniciante
        else if (containsKeyword(userMessage, ['iniciante', 'comecar', 'zero'])) {
            response = `🎯 **Bem-vindo!**\n\n` +
                `**Áreas:**\n` +
                `💻 Programação\n` +
                `🎨 Design\n` +
                `📊 Marketing\n\n` +
                `Qual te atrai?`;
            suggestedCourses = [1, 4, 19, 31];
        }
        // Grátis
        else if (containsKeyword(userMessage, ['gratis', 'gratuito', 'free'])) {
            response = `🎁 **Cursos Gratuitos:**\n\n` +
                `✅ Inglês - 80h\n` +
                `✅ Espanhol - 70h`;
            suggestedCourses = [56, 58];
        }
        // Saudação
        else if (containsKeyword(userMessage, ['oi', 'ola', 'hello'])) {
            response = `Olá! 👋\n\n` +
                `Sou do **CursosPlat**.\n\n` +
                `Posso ajudar com:\n` +
                `• Cursos\n` +
                `• Carreiras\n` +
                `• Dicas de tech\n\n` +
                `O que quer aprender?`;
            suggestedCourses = [];
        }
        // Padrão
        else {
            response = `Interessante! 🤔\n\n` +
                `Posso ajudar com:\n\n` +
                `📚 Cursos de:\n` +
                `• Programação\n` +
                `• Design\n` +
                `• Marketing\n` +
                `• Data Science\n\n` +
                `Sobre o que quer saber?`;
            suggestedCourses = [];
        }
        
        console.log('✅ Resposta enviada');
        res.json({ response, suggestedCourses });
        
    } catch (error) {
        console.error('❌ Erro no chat:', error);
        res.status(500).json({ 
            response: 'Ops! Tive um problema. 😅\n\nPergunte sobre cursos ou carreiras!',
            suggestedCourses: []
        });
    }
});

module.exports = router;
