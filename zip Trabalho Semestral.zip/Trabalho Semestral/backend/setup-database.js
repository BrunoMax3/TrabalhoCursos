const { Pool } = require('pg');
const bcrypt = require('bcrypt');

async function setupDatabase() {
    // Conectar como postgres para criar o database
    const adminPool = new Pool({
        user: 'postgres',
        host: 'localhost',
        database: 'postgres',
        password: 'sua_senha', // AJUSTE AQUI
        port: 5432,
    });

    try {
        console.log('🔄 Verificando se database existe...');
        
        // Verificar se database já existe
        const dbCheck = await adminPool.query(
            "SELECT 1 FROM pg_database WHERE datname = 'plataforma_cursos'"
        );
        
        if (dbCheck.rows.length === 0) {
            console.log('📦 Criando database plataforma_cursos...');
            await adminPool.query('CREATE DATABASE plataforma_cursos');
            console.log('✅ Database criado!');
        } else {
            console.log('✅ Database já existe!');
        }
        
        await adminPool.end();
        
        // Conectar ao novo database
        const pool = new Pool({
            user: 'postgres',
            host: 'localhost',
            database: 'plataforma_cursos',
            password: 'sua_senha', // AJUSTE AQUI
            port: 5432,
        });
        
        console.log('\n🔄 Criando tabelas...');
        
        // Criar tabela users
        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role VARCHAR(50) DEFAULT 'user',
                interests TEXT[],
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log('✅ Tabela users criada!');
        
        // Criar tabela courses
        await pool.query(`
            CREATE TABLE IF NOT EXISTS courses (
                id SERIAL PRIMARY KEY,
                title VARCHAR(255) NOT NULL,
                description TEXT,
                duration VARCHAR(50),
                rating DECIMAL(2,1),
                icon VARCHAR(10),
                category VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log('✅ Tabela courses criada!');
        
        // Criar tabela user_courses
        await pool.query(`
            CREATE TABLE IF NOT EXISTS user_courses (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                course_id INTEGER REFERENCES courses(id) ON DELETE CASCADE,
                progress INTEGER DEFAULT 0,
                enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, course_id)
            )
        `);
        console.log('✅ Tabela user_courses criada!');
        
        // Verificar se admin já existe
        const adminCheck = await pool.query(
            "SELECT 1 FROM users WHERE email = 'admin@plataforma.com'"
        );
        
        if (adminCheck.rows.length === 0) {
            console.log('\n🔄 Criando usuário administrador...');
            const hashedPassword = await bcrypt.hash('admin123', 10);
            
            await pool.query(
                'INSERT INTO users (name, email, password, role) VALUES ($1, $2, $3, $4)',
                ['Administrador', 'admin@plataforma.com', hashedPassword, 'admin']
            );
            console.log('✅ Admin criado!');
            console.log('📧 Email: admin@plataforma.com');
            console.log('🔑 Senha: admin123');
        } else {
            console.log('\n✅ Usuário admin já existe!');
        }
        
        // Verificar se há cursos
        const coursesCheck = await pool.query('SELECT COUNT(*) FROM courses');
        
        if (parseInt(coursesCheck.rows[0].count) === 0) {
            console.log('\n🔄 Inserindo cursos de exemplo...');
            
            const courses = [
                ['React.js - Do Zero ao Avançado', 'Aprenda React do básico ao avançado', '40h', 4.8, '⚛️', 'Frontend'],
                ['Node.js e Express', 'Backend completo com Node.js', '35h', 4.9, '⚙️', 'Backend'],
                ['PostgreSQL Avançado', 'Banco de dados relacional', '28h', 4.7, '🗄️', 'Backend'],
                ['Python para Data Science', 'Análise de dados com Python', '45h', 4.9, '🐍', 'Data Science'],
                ['Vue.js 3 Completo', 'Framework progressivo', '32h', 4.8, '🎨', 'Frontend'],
                ['TypeScript na Prática', 'JavaScript com tipagem estática', '24h', 4.7, '💻', 'Frontend'],
                ['Docker e Kubernetes', 'Containerização e orquestração', '30h', 4.9, '🐳', 'DevOps'],
                ['AWS Essentials', 'Computação em nuvem', '38h', 4.8, '☁️', 'Cloud']
            ];
            
            for (const course of courses) {
                await pool.query(
                    'INSERT INTO courses (title, description, duration, rating, icon, category) VALUES ($1, $2, $3, $4, $5, $6)',
                    course
                );
            }
            
            console.log(`✅ ${courses.length} cursos inseridos!`);
        } else {
            console.log(`\n✅ Já existem ${coursesCheck.rows[0].count} cursos no banco!`);
        }
        
        await pool.end();
        
        console.log('\n🎉 Setup completo!');
        console.log('\n📝 Próximos passos:');
        console.log('1. Execute: npm start');
        console.log('2. Abra o frontend no navegador');
        console.log('3. Faça login com admin@plataforma.com / admin123');
        
    } catch (error) {
        console.error('❌ Erro:', error.message);
        process.exit(1);
    }
}

setupDatabase();
