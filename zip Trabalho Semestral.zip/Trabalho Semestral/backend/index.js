require('dotenv').config(); // Carrega as variáveis do .env

const OpenAI = require('openai').default; // Use CommonJS require and grab default export

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY, // Use a chave da API
});

// Remover console.log para não vazar a chave e exportar o cliente:
module.exports = openai;
