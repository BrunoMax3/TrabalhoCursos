-- Criar database
CREATE DATABASE plataforma_cursos;

-- Conectar ao database
\c plataforma_cursos;

-- Tabela de usuários
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'user',
    interests TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de cursos
CREATE TABLE courses (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    duration VARCHAR(50),
    rating DECIMAL(2,1),
    icon VARCHAR(10),
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de relação usuário-curso
CREATE TABLE user_courses (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    course_id INTEGER REFERENCES courses(id) ON DELETE CASCADE,
    progress INTEGER DEFAULT 0,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, course_id)
);

-- Inserir usuário admin padrão (senha: admin123)
-- NOTA: Execute este INSERT depois de rodar o servidor pela primeira vez
-- OU use o bcrypt para gerar o hash correto
INSERT INTO users (name, email, password, role) 
VALUES ('Administrador', 'admin@plataforma.com', '$2b$10$YourHashHere', 'admin');

-- Inserir cursos de exemplo
INSERT INTO courses (title, description, duration, rating, icon, category) VALUES
('React.js - Do Zero ao Avançado', 'Aprenda React do básico ao avançado', '40h', 4.8, '⚛️', 'Frontend'),
('Node.js e Express', 'Backend completo com Node.js', '35h', 4.9, '⚙️', 'Backend'),
('PostgreSQL Avançado', 'Banco de dados relacional', '28h', 4.7, '🗄️', 'Backend'),
('Python para Data Science', 'Análise de dados com Python', '45h', 4.9, '🐍', 'Data Science'),
('Vue.js 3 Completo', 'Framework progressivo', '32h', 4.8, '🎨', 'Frontend');
